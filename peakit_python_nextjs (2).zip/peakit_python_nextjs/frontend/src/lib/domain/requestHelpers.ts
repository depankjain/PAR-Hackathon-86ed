import { STORE } from "./menu";
import { getStoreState } from "./storeState";

/** Every tool-endpoint request body may optionally carry a storeId; this
 * prototype only ever runs one demo store, so we default to it — the real
 * backend requires storeId explicitly (it's a path segment there, since
 * a production deployment serves many real stores). */
export function resolveState(body: Record<string, unknown>) {
  const storeId = typeof body.storeId === "string" ? body.storeId : STORE.storeId;
  return getStoreState(storeId);
}
