"use client";

import { useState, useRef, useEffect } from "react";
import { AgentAskResponseDto, ToolCallDto } from "@/lib/types";

const SUGGESTED_QUERIES = [
  "Are we going to run out of anything in the next 45 minutes?",
  "What's the next hour looking like across the board?",
  "What's our current stock on corn cup?",
];

type Message =
  | { role: "manager"; text: string }
  | { role: "agent"; text: string; toolCalls?: ToolCallDto[] };

function ToolTrail({ toolCalls }: { toolCalls: ToolCallDto[] }) {
  const [open, setOpen] = useState(false);
  if (!toolCalls?.length) return null;
  return (
    <div className="mt-2">
      <button
        onClick={() => setOpen((o) => !o)}
        className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800"
      >
        {open ? "Hide" : "Show"} tool-call audit trail ({toolCalls.length})
      </button>
      {open && (
        <div className="mt-2 rounded-lg border border-dashed border-indigo-200 bg-indigo-50/60 p-3 font-mono text-[11px] text-indigo-900 space-y-2">
          {toolCalls.map((c, i) => (
            <div key={i}>
              <div className="font-bold">{c.toolName} <span className="font-normal text-indigo-500">[{c.sourceSystem}]</span></div>
              <div>in: {JSON.stringify(c.inputs)}</div>
              <div>out: {JSON.stringify(c.output)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function ChatPanel({
  onAsk,
}: {
  onAsk: (query: string) => Promise<AgentAskResponseDto>;
}) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "agent",
      text: "Hi — I'm PeaKit. Ask me about current stock, restock timing, or the next hour's demand forecast.",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function send(query: string) {
    if (!query.trim() || busy) return;
    setMessages((m) => [...m, { role: "manager", text: query }]);
    setInput("");
    setBusy(true);
    try {
      const response = await onAsk(query);
      setMessages((m) => [...m, { role: "agent", text: response.recommendation, toolCalls: response.toolCalls }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "agent", text: `Something went wrong reaching the backend: ${(err as Error).message}` }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col h-[640px]">
      <div className="px-5 py-4 border-b border-slate-100">
        <h2 className="text-sm font-bold text-slate-800">Ask PeaKit</h2>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "manager" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                m.role === "manager"
                  ? "bg-indigo-600 text-white rounded-tr-sm"
                  : "bg-slate-100 text-slate-800 rounded-tl-sm"
              }`}
            >
              {m.text}
              {m.role === "agent" && m.toolCalls && <ToolTrail toolCalls={m.toolCalls} />}
            </div>
          </div>
        ))}
        {busy && <div className="text-xs text-slate-400 italic">PeaKit is reading live store data…</div>}
      </div>

      <div className="px-5 py-3 border-t border-slate-100 space-y-2">
        <div className="flex flex-wrap gap-2">
          {SUGGESTED_QUERIES.map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              disabled={busy}
              className="text-[11px] rounded-full border border-slate-200 hover:border-indigo-400 hover:text-indigo-600 px-3 py-1.5 text-slate-600 disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a question…"
            className="flex-1 rounded-full border border-slate-200 px-4 py-2 text-sm outline-none focus:border-indigo-400"
          />
          <button
            type="submit"
            disabled={busy}
            className="rounded-full bg-indigo-600 text-white text-sm font-semibold px-4 py-2 disabled:opacity-50"
          >
            Ask
          </button>
        </form>
      </div>
    </div>
  );
}
