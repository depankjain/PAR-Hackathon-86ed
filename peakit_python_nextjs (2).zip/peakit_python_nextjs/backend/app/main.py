"""FastAPI application entry point: CORS, router includes, and startup
seeding of the demo store."""
from __future__ import annotations

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import agent, stores, tools
from app.seed import init_db_and_seed

logging.basicConfig(level=logging.INFO)

settings = get_settings()

app = FastAPI(
    title="PeaKit API",
    description=(
        "Real-time restaurant store-manager assistant API: current stock, "
        "restock timing, and demand forecast + runout + footfall."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(stores.router)
app.include_router(tools.router)
app.include_router(agent.router)


@app.on_event("startup")
def on_startup() -> None:
    init_db_and_seed()


@app.get("/health", tags=["health"])
def health() -> dict:
    return {"status": "ok"}
