"""SQLAlchemy engine / session setup.

We use the classic *sync* SQLAlchemy API (2.x style) for simplicity - FastAPI
happily runs sync endpoint code in its threadpool, and it keeps this hackathon
prototype's plumbing easy to reason about. If this were graduating beyond a
demo, switching to the async engine + asyncpg would be a natural next step.
"""
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_settings

settings = get_settings()

engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
