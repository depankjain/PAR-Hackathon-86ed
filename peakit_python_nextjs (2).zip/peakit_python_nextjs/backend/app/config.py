"""Application configuration via pydantic-settings.

All values can be overridden with environment variables (see .env.example).
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Database
    database_url: str = "postgresql+psycopg://peakit:peakit@localhost:5433/peakit"

    # AI reasoning provider seam: "local" (default, no AWS needed) or "bedrock"
    peakit_ai_provider: str = "local"
    peakit_bedrock_model_id: str = "anthropic.claude-3-5-sonnet-20241022-v2:0"
    aws_region: str = "us-east-1"

    # CORS - comma separated list of allowed origins
    cors_allowed_origins: str = "http://localhost:3000"

    # The single demo store this hackathon prototype targets
    default_store_id: str = "IN-BLR-0142"

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_allowed_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
