/**
 * In-memory live-store state — the TypeScript mirror of the Python
 * prototype's LiveStoreState class. Plays the role that a real read
 * against Punchh + PAR POS + PAR OPS would play in production.
 *
 * IMPORTANT — this module-level Map is intentionally simple and is ONLY
 * appropriate for local development / the mock API described in
 * docs/ARCHITECTURE.md. It resets whenever the Next.js dev server
 * restarts and would NOT persist correctly across multiple serverless
 * function instances in a real deployment. The real backend (Python/FastAPI)
 * persists the equivalent state in PostgreSQL — see
 * backend/src/main/java/.../entity/InventoryLevel.java and friends.
 */

import { MENU_ITEMS } from "./menu";

export interface StoreState {
  storeId: string;
  storeName: string;
  simTime: Date;
  weather: string;
  inventory: Record<string, number>;
}

const stores = new Map<string, StoreState>();

function freshState(storeId: string): StoreState {
  return {
    storeId,
    storeName: "PeaKit Demo Kitchen — Koramangala",
    // Friday, 7:04pm — the same reference moment used throughout the
    // architecture docs and the original Python prototype's run_demo.py.
    simTime: new Date(2026, 8, 18, 19, 4),
    weather: "clear",
    inventory: {
      chicken_original: 28, // already below par (60)
      corn_cup: 17,         // critically low against par (40)
      fries_reg: 64,
      beverage_cola: 210,
    },
  };
}

export function getStoreState(storeId: string): StoreState {
  if (!stores.has(storeId)) {
    stores.set(storeId, freshState(storeId));
  }
  return stores.get(storeId)!;
}

export function resetStoreState(storeId: string): StoreState {
  const fresh = freshState(storeId);
  stores.set(storeId, fresh);
  return fresh;
}

export function advanceClock(storeId: string, minutes: number): StoreState {
  const state = getStoreState(storeId);
  state.simTime = new Date(state.simTime.getTime() + minutes * 60_000);
  for (const itemId of Object.keys(state.inventory)) {
    const rate = MENU_ITEMS[itemId]?.sellThroughPerMin ?? 0;
    const consumed = rate * minutes;
    state.inventory[itemId] = Math.max(0, Math.round((state.inventory[itemId] - consumed) * 10) / 10);
  }
  return state;
}
