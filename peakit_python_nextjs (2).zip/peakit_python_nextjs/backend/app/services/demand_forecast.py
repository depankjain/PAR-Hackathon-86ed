"""Deterministic demand-forecast formula.

This is intentionally NEVER delegated to an AI model - it is plain
arithmetic so results are reproducible and auditable, exactly mirroring the
Java reference implementation.
"""
from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

# hour of day (in the store's local timezone) -> fraction of daily volume
BASE_HOURLY_WEIGHTS: dict[int, float] = {
    11: 0.06,
    12: 0.10,
    13: 0.09,
    14: 0.05,
    15: 0.03,
    16: 0.03,
    17: 0.05,
    18: 0.09,
    19: 0.14,
    20: 0.16,
    21: 0.12,
    22: 0.08,
}
DEFAULT_HOURLY_WEIGHT = 0.02

# Monday=0 .. Sunday=6 (matches Python's datetime.weekday())
DAY_OF_WEEK_MULTIPLIER: dict[int, float] = {
    0: 0.85,
    1: 0.85,
    2: 0.90,
    3: 0.95,
    4: 1.25,
    5: 1.35,
    6: 1.10,
}

WEATHER_MODIFIERS: dict[str, float] = {"clear": 1.00, "rain": 1.18, "heatwave": 0.92}
DEFAULT_WEATHER_MODIFIER = 1.0


def expected_units_in_window(
    daily_volume: float,
    at_utc: datetime,
    timezone_str: str,
    window_minutes: int,
    weather: str,
) -> float:
    """Predicted unit sales in `window_minutes` starting at `at_utc`."""
    if at_utc.tzinfo is None:
        # Some DB drivers (notably SQLite, used only for this project's
        # offline smoke tests) hand back naive datetimes even though the
        # column is conceptually UTC. `datetime.astimezone()` on a naive
        # value assumes the *host's local* timezone as the source, which
        # silently produces wrong results - so we pin naive input to UTC
        # explicitly before converting to the store's local timezone.
        at_utc = at_utc.replace(tzinfo=timezone.utc)
    local = at_utc.astimezone(ZoneInfo(timezone_str))
    weight = BASE_HOURLY_WEIGHTS.get(local.hour, DEFAULT_HOURLY_WEIGHT)
    dow_mult = DAY_OF_WEEK_MULTIPLIER[local.weekday()]
    weather_mult = WEATHER_MODIFIERS.get(weather, DEFAULT_WEATHER_MODIFIER)
    hourly_units = daily_volume * weight * dow_mult * weather_mult
    predicted = hourly_units * (window_minutes / 60.0)
    return round(predicted, 1)
