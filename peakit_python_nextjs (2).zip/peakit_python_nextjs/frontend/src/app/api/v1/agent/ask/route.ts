import { NextRequest, NextResponse } from "next/server";
import { STORE } from "@/lib/domain/menu";
import { getStoreState } from "@/lib/domain/storeState";
import { handleQuery } from "@/lib/domain/agent";

// POST /api/v1/agent/ask
// Mock implementation of the manager-facing entry point. Swap
// NEXT_PUBLIC_API_BASE_URL to the real Python (FastAPI) backend and the
// frontend calls AgentController -> AgentOrchestrationService, which
// calls AiReasoningPort (LocalStubReasoningAdapter or
// BedrockReasoningAdapter) instead of this route's handleQuery().
export async function POST(req: NextRequest) {
  const body = await req.json();
  const storeId = typeof body.storeId === "string" ? body.storeId : STORE.storeId;
  const state = getStoreState(storeId);
  const response = handleQuery(state, body.query ?? "");
  return NextResponse.json(response);
}
