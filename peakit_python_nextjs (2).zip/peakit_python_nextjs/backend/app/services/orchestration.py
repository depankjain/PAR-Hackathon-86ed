"""The `/agent/ask` dispatcher.

Classifies intent via the configured `AiReasoningPort` implementation, then
calls the deterministic tool functions in-process (sharing one `request_id`
so their audit rows group together under this ask), and assembles a
human-readable recommendation string.
"""
from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import MenuItem
from app.services import tools_service
from app.services.audit_log import fetch_recent, to_wire
from app.services.reasoning.base import FORECAST_CHECK, GENERAL_STATUS, RUNOUT_CHECK
from app.services.reasoning.bedrock_adapter import BedrockReasoning
from app.services.reasoning.local_stub import LocalStubReasoning

# Canonical menu order, matching the seed data.
MENU_ITEM_IDS = ["chicken_original", "corn_cup", "fries_reg", "beverage_cola"]
RUNOUT_WATCH_ITEM_IDS = ["chicken_original", "corn_cup"]

_INTENT_TO_WIRE = {
    RUNOUT_CHECK: "runout_check",
    FORECAST_CHECK: "forecast_check",
    GENERAL_STATUS: "general_status",
}


def _get_reasoning_port():
    settings = get_settings()
    if settings.peakit_ai_provider.lower() == "bedrock":
        return BedrockReasoning()
    return LocalStubReasoning()


def _menu_item_name(db: Session, item_id: str) -> str:
    item = db.get(MenuItem, item_id)
    return item.name if item else item_id


def _handle_runout_check(db: Session, store_id: str, request_id: str) -> str:
    lines: list[str] = []
    worst_item_id: str | None = None
    worst_minutes: float | None = None

    for item_id in RUNOUT_WATCH_ITEM_IDS:
        name = _menu_item_name(db, item_id)
        prep = tools_service.required_prep_for_window(
            db, store_id=store_id, item_id=item_id, window_minutes=45, request_id=request_id
        )
        runout = tools_service.predict_runout(
            db, store_id=store_id, item_id=item_id, request_id=request_id
        )
        minutes_to_runout = runout["minutesToRunout"]

        if prep["shortfallUnits"] > 0:
            minutes_display = (
                "Infinity" if minutes_to_runout == "Infinity" else f"{minutes_to_runout:.0f}"
            )
            lines.append(
                f"{name}: need {prep['shortfallUnits']:.0f} more in the next 45 min "
                f"(runs out in ~{minutes_display} min at current pace)"
            )

        if minutes_to_runout != "Infinity":
            if worst_minutes is None or minutes_to_runout < worst_minutes:
                worst_minutes = minutes_to_runout
                worst_item_id = item_id

    if lines:
        if worst_item_id is not None:
            tools_service.create_restock_reminder(
                db,
                store_id=store_id,
                item_id=worst_item_id,
                quantity_hint=None,
                request_id=request_id,
            )
        return "You'll need " + "; ".join(lines) + ". Want me to fire a restock reminder?"

    return (
        "Inventory is tracking fine against the next 45 minutes of forecast demand "
        "— no action needed."
    )


def _handle_forecast_check(db: Session, store_id: str, request_id: str) -> str:
    lines: list[str] = []
    for item_id in MENU_ITEM_IDS:
        name = _menu_item_name(db, item_id)
        forecast = tools_service.forecast_demand(
            db, store_id=store_id, item_id=item_id, window_minutes=60, request_id=request_id
        )
        lines.append(f"{name}: ~{forecast['predictedUnits']:.0f} in the next hour")
    return "Next-hour forecast — " + "; ".join(lines) + "."


def _handle_general_status(db: Session, store_id: str, request_id: str) -> str:
    lines: list[str] = []
    for item_id in MENU_ITEM_IDS:
        name = _menu_item_name(db, item_id)
        inv = tools_service.get_inventory_level(
            db, store_id=store_id, item_id=item_id, request_id=request_id
        )
        lines.append(f"{name}: {inv['onHand']:.0f} {inv['unit']}")
    return "Current stock — " + "; ".join(lines)


def ask(db: Session, *, store_id: str, query: str) -> dict[str, Any]:
    reasoning = _get_reasoning_port()
    intent = reasoning.classify_intent(query)

    request_id = tools_service.new_request_id()

    if intent == RUNOUT_CHECK:
        recommendation = _handle_runout_check(db, store_id, request_id)
    elif intent == FORECAST_CHECK:
        recommendation = _handle_forecast_check(db, store_id, request_id)
    else:
        intent = GENERAL_STATUS
        recommendation = _handle_general_status(db, store_id, request_id)

    rows = [row for row in fetch_recent(db, store_id=store_id, limit=50) if row.request_id == request_id]
    rows.sort(key=lambda r: r.id)  # chronological order of the tool calls made during this ask
    tool_calls = [to_wire(row) for row in rows]

    return {
        "query": query,
        "intent": _INTENT_TO_WIRE[intent],
        "recommendation": recommendation,
        "toolCalls": tool_calls,
    }
