# PeaKit — Full Code Walkthrough (Python / FastAPI backend + Next.js frontend)

This document explains **every file** in `peakit_python_nextjs/`, line by line where it matters, so someone who has never seen this codebase can understand exactly how it works and why it was built this way. It also narrates the order the pieces were actually built in, and why.

If you only read one section, read **Part 3: How a request actually flows through the system** — it ties every file below into one concrete story.

---

## Part 0 — The idea in one paragraph

PeaKit answers exactly three questions a restaurant store manager asks every shift: *how much of this do we have left*, *when should we restock it*, and *how much will we sell / how busy will we get*. Every number that goes into an answer comes from a small set of plain-arithmetic "tools" — never from the AI model. The AI model's only job is to figure out **which** of those three questions is being asked (that's called "intent classification"). This split — AI decides *what*, code computes *the number* — is the single most important design decision in this whole project, and it shows up in almost every file below.

---

## Part 1 — Repository layout

```
peakit_python_nextjs/
  api-contract/
    openapi.yaml            <- the contract both backend and frontend implement
  backend/                  <- Python 3.11 + FastAPI + SQLAlchemy + Postgres
    app/
      main.py                FastAPI app object, CORS, startup hook
      config.py               all settings (env vars), one place
      db.py                   SQLAlchemy engine/session plumbing
      models.py                the 4 database tables, as Python classes
      schemas.py               the JSON shapes going in/out of the API
      seed.py                  fills the database with the demo scenario
      routers/
        stores.py              4 endpoints: state / advance / reset / audit-log
        tools.py                5 endpoints: the individual tools
        agent.py                 1 endpoint: /agent/ask (the "smart" one)
      services/
        demand_forecast.py       the forecasting math
        tools_service.py          the 5 tools' actual logic + audit logging
        store_state.py             builds the "current state" JSON + advances the clock
        audit_log.py                saves/reads tool-call history
        time_utils.py                one small datetime-formatting helper
        orchestration.py             the brain: decides intent, calls tools, writes an answer
        reasoning/
          base.py                    the shared interface both AI implementations follow
          local_stub.py                keyword-matching "AI" (default, free, offline)
          bedrock_adapter.py            real AWS Bedrock (Claude) call, with safe fallback
    tests/
      conftest.py                 test setup (points the app at a throwaway SQLite file)
      test_demand_forecast.py      tests with no database at all
      test_api_sqlite_smoke.py      tests that hit every endpoint through FastAPI
    requirements.txt, Dockerfile, docker-compose.yml, .env.example, README.md
  frontend/                  <- Next.js (React) app
    src/
      app/
        page.tsx               the one page of the whole app
        layout.tsx               HTML shell + page title
        api/v1/**/route.ts        a *fake* backend, built into the frontend itself
      components/
        Header.tsx, Dashboard.tsx, ChatPanel.tsx      the 3 visual pieces
      lib/
        api-client.ts             the ONLY file that knows the backend's URL
        types.ts                    shared TypeScript shapes
        domain/                      the fake backend's actual logic (mirrors the Python backend)
    package.json, next.config.ts, README.md
```

Two independent things live here on purpose: a **real backend** (`backend/`, Python) and a **fake/mock backend built into the frontend** (`frontend/src/app/api/v1/**` + `frontend/src/lib/domain/`). The frontend can run against either one by changing a single setting. This lets anyone open the app immediately with `npm install && npm run dev` — no Python, no Postgres, nothing — while the real backend exists for when you want real persistence and a real AI call.

---

## Part 2 — The backend, file by file

### 2.1 `app/config.py` — every setting, in one place

```python
class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://peakit:peakit@localhost:5433/peakit"
    peakit_ai_provider: str = "local"
    peakit_bedrock_model_id: str = "anthropic.claude-3-5-sonnet-20241022-v2:0"
    aws_region: str = "us-east-1"
    cors_allowed_origins: str = "http://localhost:3000"
    default_store_id: str = "IN-BLR-0142"
```

This uses **pydantic-settings**, a library that automatically reads environment variables (or a `.env` file) into a typed Python object. `class Settings(BaseSettings)` means: "every attribute below is a setting; if an environment variable with this name (case-insensitive) exists, use it, otherwise use the default shown."

- `database_url` — how to reach Postgres. The default points at `localhost:5433` (not the usual 5432 — see `docker-compose.yml` below for why).
- `peakit_ai_provider` — the switch between the free keyword-matching "AI" and the real AWS Bedrock call. Defaults to `"local"` so nothing costs money or needs AWS credentials unless you explicitly opt in.
- `default_store_id` — this whole project is a **single-store demo**. Every tool defaults to this one store if not told otherwise.

```python
@lru_cache
def get_settings() -> Settings:
    return Settings()
```

`@lru_cache` is a decorator that means "run this function once, remember the answer, and hand back the same answer every time it's called again." It's used here so that (a) reading environment variables only happens once at startup, not on every single request, and (b) every file that needs a setting calls `get_settings()` and gets the exact same object.

### 2.2 `app/db.py` — connecting to the database

```python
engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

class Base(DeclarativeBase):
    pass

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

`create_engine` doesn't actually connect to anything yet — it just remembers *how* to connect. `pool_pre_ping=True` means: before reusing a saved connection, quickly check it's still alive (Postgres/cloud databases sometimes silently drop idle connections; without this you'd get a confusing error the first time that happens).

`Base` is the parent class every database table (in `models.py`) inherits from — SQLAlchemy uses it to know which Python classes correspond to real tables.

`get_db()` is a **generator function** (note `yield`, not `return`). FastAPI has a feature called "dependency injection": if an endpoint function has a parameter like `db: Session = Depends(get_db)`, FastAPI will call `get_db()` for you, hand the `Session` (a live database handle) to your endpoint, and — critically — once your endpoint function returns, FastAPI resumes `get_db()` past the `yield`, which runs `db.close()`. This guarantees every database connection gets closed after every request, even if the endpoint raised an error, without every endpoint having to remember to do it manually.

### 2.3 `app/models.py` — the 4 database tables

Each class here is one SQL table. For example:

```python
class Store(Base):
    __tablename__ = "stores"
    store_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), nullable=False)
    weather: Mapped[str] = mapped_column(String(16), nullable=False, default="clear")
    sim_time_override: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
```

`Mapped[str]` and `mapped_column(...)` are SQLAlchemy 2.x's modern syntax for "this Python attribute is a real database column of this SQL type." `primary_key=True` marks `store_id` as the table's unique identifier. `sim_time_override` is nullable and holds the *fake* "current time" this demo uses instead of the real clock (explained more in `store_state.py` below) — its name literally means "override the real time with this."

The other three tables:
- `MenuItem` — one row per menu item (chicken, corn, fries, cola), holding static facts like `par_level` (how much stock they're supposed to keep on hand) and `sell_through_per_min` (how fast it normally sells).
- `InventoryLevel` — one row per (store, item) pair, holding the live `on_hand` quantity. This is the number that changes as time passes.
- `ToolCallAuditLog` — one row **every time any tool is called**, recording exactly what was asked and what came back. This is what powers the "audit trail" the chat UI shows — nothing PeaKit says is untraceable.

```python
_ID_TYPE = BigInteger().with_variant(Integer, "sqlite")
```

This one line is a compatibility shim. `InventoryLevel` and `ToolCallAuditLog` use auto-incrementing numeric IDs. On real Postgres these are `BIGSERIAL` (a `BigInteger` that counts up automatically). But this project's automated tests run against SQLite instead of Postgres (no Postgres was available in the sandbox this was built in — see Part 5), and SQLite's auto-increment behavior only activates for a plain `INTEGER` primary key, not `BIGINT`. `.with_variant(Integer, "sqlite")` says "use `BigInteger` normally, but if we're talking to SQLite specifically, use plain `Integer` instead." Production (Postgres) is completely unaffected by this line.

### 2.4 `app/schemas.py` — the JSON shapes

This file defines, using **Pydantic** (a validation library), exactly what every request body and response body looks like. Example:

```python
class ForecastRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    item_id: str = Field(alias="itemId")
    window_minutes: int = Field(alias="windowMinutes")
```

Why the `alias=`? Python convention is `snake_case` (`item_id`), but the shared API contract (`api-contract/openapi.yaml`) — which this Python backend must match exactly so the frontend can talk to either backend interchangeably — uses `camelCase` (`itemId`), because that's the JavaScript/JSON convention the Next.js frontend and the OpenAPI spec use. `Field(alias="itemId")` means: "internally, in Python code, call this `item_id`; but when reading from or writing to JSON, use `itemId`." `populate_by_name=True` additionally allows constructing the object from Python using the snake_case name too (handy for tests). FastAPI is configured (by default) to serialize responses using the alias, so every response that leaves this backend is camelCase, matching the contract exactly.

Every other class in this file (`InventoryResponse`, `RunoutResponse`, `AgentAskRequest`, `AgentAskResponse`, `StoreState`, `ToolCall`, ...) follows this exact same pattern — one class per shape, camelCase aliases throughout.

One deliberate oddity: `RunoutResponse.minutes_to_runout: Union[float, str]`. Normally this is a number. But if an item's sell-through rate is `0` (nothing selling), "minutes until it runs out" is mathematically infinite — and JSON has no `Infinity` value. So this field is typed to accept *either* a float *or* the literal string `"Infinity"`, and the code returns that string in that one edge case. This is documented again in `tools_service.py` where it actually happens.

### 2.5 `app/seed.py` — filling the database with the demo scenario

```python
DEMO_STORE_ID = "IN-BLR-0142"
SEED_SIM_TIME = datetime(2026, 9, 18, 13, 34, 0, tzinfo=timezone.utc)  # Fri 2026-09-18 19:04 IST
```

This whole project uses **one fixed, fake "current moment"**: Friday, September 18th 2026, 7:04pm India time. Every demo, every test, every screenshot uses this exact moment so numbers are reproducible and comparable across the Python backend, the Next.js mock, and the (separate) Java reference backend.

```python
MENU_ITEMS = [
    dict(item_id="chicken_original", name="Original Recipe Chicken (pc)", ..., daily_volume=420, sell_through_per_min=0.62),
    ...
]
INITIAL_ON_HAND = {"chicken_original": 28, "corn_cup": 17, "fries_reg": 64, "beverage_cola": 210}
```

Four menu items, with chicken and corn cup deliberately seeded *below* their par level (60 and 40 respectively) — this is what makes the "will we run out of anything" demo question interesting to answer.

```python
def seed_demo_data(db: Session) -> None:
    store = db.get(Store, DEMO_STORE_ID)
    if store is None:
        store = Store(...)
        db.add(store)
    for spec in MENU_ITEMS:
        item = db.get(MenuItem, spec["item_id"])
        if item is None:
            db.add(MenuItem(**spec))
    ...
```

Every `if X is None:` check here is what makes this function **idempotent** — safe to call every time the app starts, even if the data is already there, without creating duplicates or crashing on a second run.

```python
def init_db_and_seed() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_demo_data(db)
    finally:
        db.close()
```

`Base.metadata.create_all(bind=engine)` is SQLAlchemy's "look at every class that inherits from `Base`, and run `CREATE TABLE IF NOT EXISTS` for each one." This is called once, at application startup (see `main.py` next) — so a brand new, empty Postgres database becomes a fully working, seeded PeaKit database automatically, with no separate migration step to remember to run.

*(Design note, documented in the backend README: this project uses `create_all()` + a hand-written seed function instead of formal migration files like the Java reference backend's Flyway `V1__init.sql`/`V2__seed_data.sql`. For a hackathon prototype whose schema won't evolve independently across environments, that's simpler with no real downside; a production system with a schema that changes over time would want real migrations instead.)*

### 2.6 `app/main.py` — wiring it all together

```python
app = FastAPI(title="PeaKit API", description="...", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(stores.router)
app.include_router(tools.router)
app.include_router(agent.router)

@app.on_event("startup")
def on_startup() -> None:
    init_db_and_seed()

@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
```

`FastAPI(...)` creates the actual web application object. `add_middleware(CORSMiddleware, ...)` is what allows a browser running the Next.js frontend on `http://localhost:3000` to successfully call this API on `http://localhost:8000` — without it, browsers block cross-origin requests by default for security. `allow_origins` is read from settings, so which frontend URLs are allowed is configurable rather than hardcoded.

`include_router(...)` — each of the three router files below defines a *group* of related endpoints; `main.py` just plugs all three groups into the one app.

`@app.on_event("startup")` registers a function to run once, automatically, the moment the server process starts — this is where `init_db_and_seed()` gets called, so you never have to remember a separate "set up the database" step.

`/health` is a trivial endpoint that just says "yes, I'm alive" — standard practice for anything that will run behind a load balancer or container orchestrator, which checks this URL periodically to know if the app needs restarting.

### 2.7 `app/routers/stores.py` — the 4 "store state" endpoints

```python
@router.get("/{store_id}/state", response_model=schemas.StoreState)
def get_state(store_id: str, db: Session = Depends(get_db)) -> dict:
    return store_state.build_state(db, store_id)
```

`@router.get("/{store_id}/state", ...)` — the `{store_id}` is a **path parameter**: FastAPI automatically extracts whatever's in that position of the URL (e.g. `/api/v1/stores/IN-BLR-0142/state` → `store_id = "IN-BLR-0142"`) and passes it in as the function argument of the same name. `response_model=schemas.StoreState` tells FastAPI: "validate and shape whatever this function returns to match the `StoreState` schema, and use that to generate the OpenAPI documentation automatically." Notice the function itself just calls out to `store_state.build_state(...)` and returns whatever it gives back — routers in this codebase are deliberately "thin": all real logic lives in `services/`, never in a router function directly.

```python
@router.post("/{store_id}/advance")
def advance(store_id: str, body: schemas.AdvanceRequest, db: Session = Depends(get_db)) -> dict:
    return store_state.advance(db, store_id, body.minutes)
```

`body: schemas.AdvanceRequest` — FastAPI sees this parameter isn't a path parameter or a recognized special type, so it knows to parse the *request body* JSON into an `AdvanceRequest` object (validating it against that schema in the process — a request missing the `minutes` field, or sending a string instead of a number, gets automatically rejected with a clear error, before your function even runs).

```python
@router.post("/{store_id}/reset")
def reset(store_id: str, db: Session = Depends(get_db)) -> dict:
    reset_demo_data(db)
    return store_state.build_state(db, store_id)
```

Comment in the code explains an important simplification: this is a **single-store demo**, so `reset` always resets the one seeded store regardless of what `store_id` was actually passed in the URL — matching how the separate Java reference backend behaves too.

```python
@router.get("/{store_id}/audit-log")
def audit_log(store_id: str, limit: int = Query(default=50, ge=1, le=500), db: Session = Depends(get_db)) -> list[dict]:
    rows = fetch_recent(db, store_id=store_id, limit=limit)
    return [to_wire(row) for row in rows]
```

`limit: int = Query(default=50, ge=1, le=500)` — this is a **query parameter** (the `?limit=20` part of a URL), with validation built directly into the type declaration: default 50 if not given, must be at least 1 (`ge` = greater-or-equal), at most 500 (`le` = less-or-equal). Sending `?limit=99999` gets automatically rejected.

### 2.8 `app/routers/tools.py` — the 5 individual tools

```python
def _store_id_param(store_id: str = Query(default=settings.default_store_id, alias="storeId")) -> str:
    return store_id
```

This tiny function is itself used as a dependency (`store_id: str = Depends(_store_id_param)` in every endpoint below) — it's a reusable way of saying "every tool endpoint accepts an optional `?storeId=...` query parameter, and if it's missing, default to the one demo store." Doing it once here means the same default logic doesn't need to be repeated five times.

```python
@router.post("/forecast", response_model=schemas.ForecastResponse)
def forecast(body: schemas.ForecastRequest, store_id: str = Depends(_store_id_param), db: Session = Depends(get_db)) -> dict:
    return tools_service.forecast_demand(db, store_id=store_id, item_id=body.item_id, window_minutes=body.window_minutes)
```

Again, deliberately thin — every one of the five endpoints here (`forecast`, `inventory`, `runout`, `required-prep`, `restock-reminder`) does nothing but unpack its request body and call the matching function in `tools_service.py`, which is where the actual work happens.

### 2.9 `app/routers/agent.py` — the one "smart" endpoint

```python
@router.post("/ask", response_model=schemas.AgentAskResponse)
def ask(body: schemas.AgentAskRequest, db: Session = Depends(get_db)) -> dict:
    return orchestration.ask(db, store_id=body.store_id, query=body.query)
```

Just one endpoint, `POST /api/v1/agent/ask`. This is what the chat UI calls when a manager types a free-text question. All the interesting logic — deciding what the question even means — lives in `orchestration.py`.

### 2.10 `app/services/demand_forecast.py` — the forecasting math

This is the one file in the whole backend explicitly, deliberately **never touched by AI**. It's the same three-factor multiplication used everywhere in this project:

```python
BASE_HOURLY_WEIGHTS = {11: 0.06, 12: 0.10, ..., 22: 0.08}  # what fraction of a full day's sales happens in this hour
DAY_OF_WEEK_MULTIPLIER = {0: 0.85, ..., 4: 1.25, 5: 1.35, 6: 1.10}  # Monday=0..Sunday=6; Fri/Sat busier
WEATHER_MODIFIERS = {"clear": 1.00, "rain": 1.18, "heatwave": 0.92}

def expected_units_in_window(daily_volume, at_utc, timezone_str, window_minutes, weather):
    if at_utc.tzinfo is None:
        at_utc = at_utc.replace(tzinfo=timezone.utc)
    local = at_utc.astimezone(ZoneInfo(timezone_str))
    weight = BASE_HOURLY_WEIGHTS.get(local.hour, 0.02)
    dow_mult = DAY_OF_WEEK_MULTIPLIER[local.weekday()]
    weather_mult = WEATHER_MODIFIERS.get(weather, 1.0)
    hourly_units = daily_volume * weight * dow_mult * weather_mult
    predicted = hourly_units * (window_minutes / 60.0)
    return round(predicted, 1)
```

Reading this step by step for the actual demo scenario (chicken, Friday 7:04pm IST, 45-minute window):
1. `local.hour` = 19 (7pm) → `weight` = 0.14 (14% of a full day's chicken sales happen in the 7pm hour).
2. `local.weekday()` = 4 (Friday, since Python counts Monday=0) → `dow_mult` = 1.25 (Fridays run 25% busier than baseline).
3. Weather is `"clear"` → `weather_mult` = 1.0 (no adjustment).
4. `hourly_units = 420 * 0.14 * 1.25 * 1.0 = 73.5` — that's the model's estimate of chicken pieces sold in a *full* hour under these conditions.
5. `predicted = 73.5 * (45/60) = 55.125`, which `round(..., 1)` turns into **55.1** — the number this project uses everywhere as the canonical "expect 55.1 pieces of chicken sold in the next 45 minutes" reference value (see the test in §2.13, and the identical value produced by the separate Java implementation).

The `if at_utc.tzinfo is None:` guard exists purely because SQLite (used only for this project's offline tests, never production) hands back datetimes with no timezone attached, and calling `.astimezone()` on a timezone-less ("naive") datetime silently assumes your *computer's* local timezone as the starting point — which would quietly produce wrong numbers depending on what machine ran the test. Explicitly stamping it as UTC first avoids that trap. Real Postgres never has this problem.

### 2.11 `app/services/tools_service.py` — the five tools, for real

Every function here follows the same shape: look something up, do arithmetic, **write a row to the audit log**, return the answer. For example:

```python
def get_inventory_level(db, *, store_id, item_id, request_id=None):
    item = _get_menu_item(db, item_id)
    inv = _get_inventory_row(db, store_id, item_id)
    output = {"itemId": item_id, "onHand": inv.on_hand, "unit": item.unit}
    record_tool_call(db, store_id=store_id, tool_name="get_inventory_level",
                      source_system="PAR OPS — Inventory", inputs={"itemId": item_id},
                      output=output, request_id=request_id or new_request_id())
    return output
```

`source_system="PAR OPS — Inventory"` names which *real* production system this tool would pull from if PeaKit were connected to actual restaurant systems instead of a seeded demo database — every tool call is labeled this way, which is exactly what shows up in the "tool-call audit trail" the chat UI can expand.

`predict_runout` is where the earlier-mentioned `"Infinity"` sentinel actually appears:

```python
rate = item.sell_through_per_min
if rate > 0:
    minutes_to_runout = round(inv.on_hand / rate, 1)
else:
    minutes_to_runout = "Infinity"
```

`required_prep_for_window` is the one tool that **calls another tool internally**:

```python
def required_prep_for_window(db, *, store_id, item_id, window_minutes, request_id=None):
    shared_request_id = request_id or new_request_id()
    forecast = forecast_demand(db, store_id=store_id, item_id=item_id,
                                window_minutes=window_minutes, request_id=shared_request_id)
    inv = _get_inventory_row(db, store_id, item_id)
    predicted_units = forecast["predictedUnits"]
    shortfall_units = max(0.0, round(predicted_units - inv.on_hand, 1))
    ...
```

Notice `shared_request_id` is generated once and passed down into the inner `forecast_demand(...)` call. This is the mechanism that makes the audit trail *group* related tool calls together: both the inner `forecast_demand` row and this function's own `required_prep_for_window` row get tagged with the exact same `request_id`, so anything reading the audit log later can tell "these two calls happened as part of answering one single question," even though they're two separate database rows written at two separate moments.

`create_restock_reminder` is the **one tool that represents taking an action** rather than just reading data — in this demo it doesn't actually change anything (there's no real kitchen task queue to write to), it just logs that the reminder *would* have been fired, tagged as sourced from `"PAR OPS — Task Queue / KDS"`.

### 2.12 `app/services/orchestration.py` — the brain

This is the most important file to understand, because it's where "AI decides what, code computes the number" actually happens in code.

```python
def ask(db, *, store_id, query):
    reasoning = _get_reasoning_port()
    intent = reasoning.classify_intent(query)
    request_id = tools_service.new_request_id()

    if intent == RUNOUT_CHECK:
        recommendation = _handle_runout_check(db, store_id, request_id)
    elif intent == FORECAST_CHECK:
        recommendation = _handle_forecast_check(db, store_id, request_id)
    else:
        intent = GENERAL_STATUS
        recommendation = _handle_general_status(db, store_id, request_id)

    rows = [row for row in fetch_recent(db, store_id=store_id, limit=50) if row.request_id == request_id]
    rows.sort(key=lambda r: r.id)
    tool_calls = [to_wire(row) for row in rows]

    return {"query": query, "intent": _INTENT_TO_WIRE[intent], "recommendation": recommendation, "toolCalls": tool_calls}
```

Step by step, for a real question like *"Are we going to run out of anything?"*:

1. `reasoning.classify_intent(query)` asks the configured AI ("local" keyword-matcher, or real Bedrock/Claude — see §2.14/§2.15) exactly one question: which of `RUNOUT_CHECK`, `FORECAST_CHECK`, or `GENERAL_STATUS` best matches this question. **The AI never sees the actual inventory numbers and is never asked to compute anything** — this is the entire point of the architecture.
2. A fresh `request_id` is generated *once*, before any tool runs.
3. Based on the intent, exactly one of three handler functions runs, and every tool call made inside that handler is passed this same `request_id`.
4. After the handler returns its human-readable `recommendation` string, the code goes back to the audit log and pulls out every row that was just written under this `request_id` — that becomes the `toolCalls` array the API returns, letting the frontend show precisely which tools fired and what they returned, for this specific question.

`_handle_runout_check` is the most elaborate handler:

```python
def _handle_runout_check(db, store_id, request_id):
    lines = []
    worst_item_id = None
    worst_minutes = None
    for item_id in RUNOUT_WATCH_ITEM_IDS:  # ["chicken_original", "corn_cup"]
        prep = tools_service.required_prep_for_window(db, store_id=store_id, item_id=item_id, window_minutes=45, request_id=request_id)
        runout = tools_service.predict_runout(db, store_id=store_id, item_id=item_id, request_id=request_id)
        minutes_to_runout = runout["minutesToRunout"]
        if prep["shortfallUnits"] > 0:
            lines.append(f"{name}: need {prep['shortfallUnits']:.0f} more in the next 45 min (runs out in ~{minutes_display} min at current pace)")
        if minutes_to_runout != "Infinity":
            if worst_minutes is None or minutes_to_runout < worst_minutes:
                worst_minutes = minutes_to_runout
                worst_item_id = item_id
    if lines:
        if worst_item_id is not None:
            tools_service.create_restock_reminder(db, store_id=store_id, item_id=worst_item_id, quantity_hint=None, request_id=request_id)
        return "You'll need " + "; ".join(lines) + ". Want me to fire a restock reminder?"
    return "Inventory is tracking fine against the next 45 minutes of forecast demand — no action needed."
```

It checks the two items known to run tight (chicken and corn cup), calls two tools for each, tracks which one is in the *worst* shape (soonest to run out), and — only if at least one item actually needs attention — automatically fires a restock reminder for the worst one and explains why in plain language. If both items are fine, it says so plainly instead of forcing an action.

`_handle_forecast_check` and `_handle_general_status` are simpler — they just loop over every menu item, call one tool per item (`forecast_demand` or `get_inventory_level`), and join the results into one sentence.

### 2.13 `app/services/reasoning/` — the AI seam

`base.py` defines the shared contract:

```python
class AiReasoningPort(Protocol):
    def classify_intent(self, query: str) -> str: ...
```

A `Protocol` in Python is a way of saying "anything with a method matching this exact signature counts as this type" — it's duck-typing made explicit, and it means `orchestration.py` can accept *either* implementation below without importing or caring which one it got.

`local_stub.py` — the default, free, offline implementation:

```python
def classify_local(query: str) -> str:
    q = query.lower()
    if "runout" in q or "run out" in q or "corn cup" in q or "chicken" in q:
        return RUNOUT_CHECK
    if "forecast" in q or "sell" in q or "demand" in q:
        return FORECAST_CHECK
    return GENERAL_STATUS
```

Genuinely just `if`/`elif` on keywords, lower-cased first so `"Chicken"` and `"chicken"` match the same way. This is intentionally simple — it exists so the whole system runs immediately with zero setup and zero cost, and so the *real* AI adapter below has something safe to fall back to.

`bedrock_adapter.py` — the real thing:

```python
class BedrockReasoning:
    def _get_client(self):
        if self._client is None:
            import boto3
            self._client = boto3.client("bedrock-runtime", region_name=self._region)
        return self._client

    def classify_intent(self, query: str) -> str:
        try:
            client = self._get_client()
            response = client.converse(
                modelId=self._model_id,
                messages=[{"role": "user", "content": [{"text": query}]}],
                toolConfig={"tools": [_CLASSIFY_TOOL], "toolChoice": {"tool": {"name": "classify_intent"}}},
            )
            ...
            return intent
        except Exception as exc:
            logger.warning("Bedrock classify_intent failed (%s); falling back to local stub", exc)
            return classify_local(query)
```

Two things worth calling out:

1. `import boto3` happens **inside** `_get_client()`, not at the top of the file. This means importing this file at all never requires AWS credentials or even the `boto3` package to be configured correctly — it's only touched the moment (if ever) `PEAKIT_AI_PROVIDER=bedrock` is actually selected and a real question comes in.
2. `toolChoice={"tool": {"name": "classify_intent"}}` **forces** the model to respond by calling this specific tool rather than replying with free-text prose — this is what guarantees the response is always one of exactly three valid enum values, never an unpredictable sentence.
3. `except Exception as exc:` is deliberately broad ("catch literally anything"). The comment explains why: a throttled API call, missing credentials, a network blip, or a malformed response should never take the whole `/agent/ask` endpoint down — it should just quietly fall back to the free keyword-matcher and keep answering the manager's question, one degree "dumber," logging a warning for whoever's operating this in production to notice.

### 2.14 `app/services/store_state.py`, `audit_log.py`, `time_utils.py`

`store_state.py`'s `advance()` function is what makes the "Advance 15 min" demo button work:

```python
def advance(db, store_id, minutes):
    store = _get_store_or_404(db, store_id)
    store.sim_time_override = store.sim_time_override + timedelta(minutes=minutes)
    rows = db.execute(select(InventoryLevel).where(InventoryLevel.store_id == store_id)).scalars().all()
    for row in rows:
        item = db.get(MenuItem, row.item_id)
        rate = item.sell_through_per_min if item else 0.0
        depleted = row.on_hand - (rate * minutes)
        row.on_hand = round(max(0.0, depleted), 1)
    db.commit()
    return build_state(db, store_id)
```

It pushes the fake clock forward, then for every item, subtracts `(sell-through rate) × (minutes passed)` from on-hand stock — a simple linear depletion model — clamped at 0 (`max(0.0, ...)` — you can't have negative stock).

`audit_log.py` is a thin persistence wrapper: `record_tool_call(...)` builds a `ToolCallAuditLog` row and saves it; `fetch_recent(...)` reads the most recent rows for a store; `to_wire(...)` converts a database row into the camelCase dict shape the API returns (deserializing the `inputs`/`output` columns, which are stored as JSON text, back into real dictionaries with `json.loads`).

`time_utils.py` is one function, `to_iso_utc_z`, used everywhere a timestamp needs to become a JSON string — it exists purely to handle the same naive-vs-aware datetime quirk mentioned in §2.10, producing a consistent `"2026-09-18T13:34:00Z"`-style string regardless of whether the database handed back a timezone-aware or timezone-naive value.

### 2.15 `tests/` — proving the above actually works

`conftest.py` runs automatically before any test file, and does one important thing: it points `DATABASE_URL` at a throwaway SQLite file *before* any other test file gets a chance to import `app.db` (which reads that setting once and caches it). Order matters here — if a test imported the real app first, it would try to connect to Postgres and fail in this sandbox.

`test_demand_forecast.py` tests pure math with no database at all — for example, hand-verifying the exact 55.1 result walked through in §2.10, plus checking the weather modifier and the "unknown hour defaults to 0.02" behavior.

`test_api_sqlite_smoke.py` is more ambitious: it spins up a real (temporary, throwaway) SQLite database, seeds it, points a live `FastAPI TestClient` at it, and then makes real HTTP-shaped calls against every single endpoint — checking exact seed values, the advance/reset math, all five tools (including deliberately inserting a zero-sell-through item just to exercise the `"Infinity"` branch), the audit-log grouping between `forecast_demand` and `required_prep_for_window`, and all three `/agent/ask` intents end-to-end. All 20 tests across both files pass; see the backend README for the full list of what was and wasn't checked and why (SQLite stands in for Postgres in this sandbox, which had no real Postgres available).

---

## Part 3 — How a request actually flows through the system (two full traces)

### Trace A: loading the dashboard

1. Browser loads `frontend/src/app/page.tsx`. Its `useEffect` calls `refresh()`, which calls `getStoreState(STORE.storeId)` from `lib/api-client.ts`.
2. `api-client.ts`'s `apiFetch` does `fetch(`${BASE_URL}/api/v1/stores/IN-BLR-0142/state`)`. `BASE_URL` is empty by default, so this hits the frontend's *own* route at `app/api/v1/stores/[storeId]/state/route.ts` — or, if `NEXT_PUBLIC_API_BASE_URL=http://localhost:8000` is set, it hits the real Python backend instead. Nothing else in the whole frontend needs to change to switch between them.
3. **Mock path:** the route handler calls `getStoreState(storeId)` from `lib/domain/storeState.ts`, which returns (or creates, on first call) an in-memory JavaScript object and hands back its fields as JSON.
   **Real path:** FastAPI's router (`routers/stores.py`) calls `store_state.build_state(db, store_id)`, which reads the `Store` and `InventoryLevel` rows from Postgres and returns the same JSON shape.
4. Either way, the JSON comes back as `{storeId, storeName, simTime, weather, inventory}`, gets set into React state, and `Dashboard.tsx` renders one card per menu item with a progress bar (`onHand / parLevel`) and a computed "minutes to runout" estimate.

### Trace B: asking "Are we going to run out of anything?"

1. Manager types the question into `ChatPanel.tsx` and hits Ask. It calls the `onAsk` prop, which is `handleAsk` in `page.tsx`, which calls `askAgent(storeId, query)` from `api-client.ts`.
2. That POSTs to `/api/v1/agent/ask` with `{storeId, query}`.
3. **Mock path:** the route handler calls `handleQuery(state, query)` from `lib/domain/agent.ts`. It runs `routeIntent(query)` (pure keyword matching, same logic as the Python `local_stub.py`), gets `"runout_check"`, and calls `handleRunout(state, query)`, which calls `requiredPrepForWindow` and `predictRunout` from `tools.ts` for chicken and corn cup, exactly mirroring §2.12's Python logic.
   **Real path:** FastAPI's `routers/agent.py` calls `orchestration.ask(db, store_id, query)`, which is the exact function walked through in §2.12 — `reasoning.classify_intent(query)` (local stub or real Bedrock), then `_handle_runout_check`, which calls `tools_service.required_prep_for_window` and `tools_service.predict_runout` for each watched item, and — since chicken and corn cup are both seeded below par — fires a restock reminder for whichever is worse.
4. Either way, the response is `{query, intent: "runout_check", recommendation: "You'll need ...", toolCalls: [...]}`.
5. Back in `ChatPanel.tsx`, the `recommendation` renders as the chat bubble text, and the `toolCalls` array renders inside the collapsible "Show tool-call audit trail" section, listing each tool's name, source system, inputs, and output — this is the receipt proving the answer wasn't invented.

---

## Part 4 — The frontend, file by file

### 4.1 `lib/types.ts` and `lib/api-client.ts`

`types.ts` is four small TypeScript interfaces (`StoreStateDto`, `ToolCallDto`, `AgentAskResponseDto`) that mirror the Python `schemas.py` shapes exactly — same field names, same nesting. Keeping these hand-in-sync (rather than auto-generating one from the other) is a deliberate simplicity trade-off for a project this size; the comment in the file flags this explicitly.

`api-client.ts` is, by design, **the only file in the entire frontend that knows the backend's URL**:

```typescript
const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {...init, headers: {...}, cache: "no-store"});
  if (!res.ok) throw new Error(`PeaKit API error ${res.status} on ${path}: ${await res.text()}`);
  return res.json();
}
```

`<T>` is a TypeScript **generic** — it lets `apiFetch` be reused for every different response shape while still giving you full type-checking at every call site (`apiFetch<StoreStateDto>(...)` "knows" its result is a `StoreStateDto`). `cache: "no-store"` tells the browser/Next.js to never cache these responses — this data changes every time the demo clock advances, so a stale cached response would show wrong numbers. Every exported function below this (`getStoreState`, `advanceStoreClock`, `resetStore`, `getAuditLog`, `askAgent`) is a one-line wrapper calling `apiFetch` with one specific URL path — this is the complete list of every API call the whole UI is capable of making.

### 4.2 `lib/domain/` — the fake backend, mirroring the real one

This whole folder exists so the app is instantly runnable with zero setup. Each file mirrors one part of the real backend:

- `menu.ts` — the same 4 seeded menu items as `backend/app/seed.py`'s `MENU_ITEMS`, hardcoded here as a TypeScript object instead of database rows.
- `demand.ts` — the exact same three-factor forecasting formula as `demand_forecast.py`, **except** it deliberately uses JavaScript's `Date.getDay()` convention (Sunday=0) instead of Python's `weekday()` convention (Monday=0) — the `DAY_OF_WEEK_MULTIPLIER` table here is reordered accordingly so the *same real-world days* still get the same multipliers; this is called out explicitly in the file's own comment, since it's exactly the kind of subtle mismatch that silently produces wrong numbers if missed.
- `storeState.ts` — an in-memory `Map<string, StoreState>` standing in for the Postgres `stores`/`inventory_levels` tables. The comment is explicit that this only works for local development: it resets whenever the dev server restarts, and would not behave correctly across multiple serverless instances in a real deployment — that's precisely the gap the real Python/Postgres backend exists to close.
- `tools.ts` — the same five tools as `tools_service.py`, logging to an in-memory array (per store) instead of a database table.
- `agent.ts` — the same `routeIntent` + three-handler-function structure as `orchestration.py`, described side-by-side in Trace B above.
- `requestHelpers.ts` — one tiny helper, `resolveState(body)`, used by the mock tool routes to default to the one demo store if a request doesn't specify `storeId` — the frontend-mock equivalent of the backend's `_store_id_param` dependency.

### 4.3 `app/api/v1/**/route.ts` — the mock routes themselves

Next.js has a convention: a file at `app/api/v1/stores/[storeId]/state/route.ts` automatically becomes the handler for `GET /api/v1/stores/:storeId/state` (or `POST`, if it exports a `POST` function instead of `GET`). Every one of these route files is short on purpose — they parse the incoming request, call one function from `lib/domain/`, and return the result as JSON:

```typescript
export async function GET(_req: NextRequest, { params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  const state = getStoreState(storeId);
  return NextResponse.json({ storeId: state.storeId, storeName: state.storeName, simTime: state.simTime.toISOString(), weather: state.weather, inventory: state.inventory });
}
```

Note `params` is a `Promise` here — that's a Next.js 15 convention (route params are asynchronous now), which is why every handler starts with `const { storeId } = await params;`.

### 4.4 `components/` and `page.tsx` — what you actually see

- `Header.tsx` — the top bar: PeaKit logo/name, and a small live clock showing the store's current simulated time.
- `Dashboard.tsx` — one `InventoryCard` per menu item (progress bar colored amber/red when stock is low, computed "minutes to runout"), plus the "Advance 15 min" / "Reset" buttons, plus a static "why this is auditable" banner explaining the design philosophy in plain language for whoever's watching the demo.
- `ChatPanel.tsx` — the chat log (manager questions right-aligned in indigo, PeaKit's replies left-aligned in gray), a collapsible `ToolTrail` component per agent reply, three clickable suggested questions, and a text input + Ask button.
- `page.tsx` — the one page tying it together: holds the `state` (from `getStoreState`) in React state, defines `handleAdvance`/`handleReset`/`handleAsk` (each calling the matching `api-client.ts` function and updating state with the response), and lays out `Header` + `Dashboard` + `ChatPanel` side by side.

---

## Part 5 — How this was actually built, step by step

1. **The contract came first.** `api-contract/openapi.yaml` was written before either backend's code, defining every endpoint's path, request shape, and response shape. Both the Python backend and the Next.js frontend's mock routes were then built *against* this contract independently — which is exactly why either one can be swapped out without touching the other.
2. **The demand-forecast formula was proven once, then ported unchanged.** The exact hourly-weight / day-of-week / weather formula in §2.10 was designed and hand-verified against one reference scenario (chicken, Friday 7:04pm IST, 45-minute window → 55.1 units) first; every implementation of it since — this Python version, the TypeScript mock, and a separate plain-Java verification module built earlier in this project — was checked against that exact same number, so "does the math agree across every language" was answered concretely rather than assumed.
3. **The reasoning seam was designed before the real AI adapter was.** `AiReasoningPort` / the `local_stub.py` keyword matcher were built first, specifically so the rest of the system (`orchestration.py`, the tool functions, the audit log) could be built and fully tested *without* needing an AWS account at all. `bedrock_adapter.py` was added afterward as a drop-in replacement behind the exact same interface — the safe-fallback-on-any-exception behavior was a deliberate requirement from the start, not an afterthought.
4. **The database layer was built to degrade gracefully to SQLite for testing**, because this project's authoring sandbox never had a real Postgres instance available. Rather than skip automated testing entirely, the schema and seed logic were written to work identically against SQLite for test purposes (with the two documented compatibility shims in §2.3 and §2.10), while staying 100% real Postgres-compatible for actual deployment — the honest state of what was and wasn't verified against real Postgres is spelled out in the backend README rather than glossed over.
5. **The frontend was built to be runnable standing completely alone**, before the real Python backend even existed, by porting the exact same tool/orchestration logic into `lib/domain/` as an in-memory TypeScript mock. This meant the UI could be designed, clicked through, and refined immediately, and it means anyone opening this project today can see the whole product work with a single `npm install && npm run dev` — no Python, no Docker, no AWS account.
6. **Tests were written against the seed scenario's exact expected numbers**, not just "does it return 200 OK" — e.g. `assert predicted == 55.1`, `assert body["inventory"]["chicken_original"] == 21.8` after advancing 10 minutes. This is what actually caught real bugs during development (like the naive-datetime timezone bug in §2.10) rather than just confirming the code runs without crashing.

---

## Part 6 — Running it for real

```bash
# Backend
cd backend
docker compose up -d              # starts Postgres on localhost:5433
pip install -r requirements.txt
uvicorn app.main:app --reload      # http://localhost:8000, auto-creates + seeds tables on startup

# Frontend, in a second terminal
cd frontend
npm install
echo "NEXT_PUBLIC_API_BASE_URL=http://localhost:8000" > .env.local
npm run dev                        # http://localhost:3000
```

Leaving `.env.local` unset (or deleting it) switches the frontend back to its own built-in mock backend — no other code changes required either way.

See `backend/README.md` and `frontend/README.md` for the full detail on what was and wasn't verified in the sandbox this was authored in, and the AI-provider environment variables (`PEAKIT_AI_PROVIDER=local` vs `bedrock`).
