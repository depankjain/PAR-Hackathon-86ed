/**
 * Static reference data — the TypeScript mirror of the Python prototype's
 * MENU_ITEMS / STORE constants (synthetic_data.py). In production, this is
 * master data that would be read from PAR OPS, not hardcoded.
 */

export interface MenuItem {
  id: string;
  name: string;
  prepMinutes: number;
  parLevel: number;
  unit: string;
  dailyVolume: number;
  sellThroughPerMin: number;
}

export const STORE = {
  storeId: "IN-BLR-0142",
  name: "Koramangala — Demo Kitchen",
  timezone: "Asia/Kolkata",
};

// Keyed by the same internal item codes used throughout the contract and
// the Python (FastAPI) backend's seed data (see backend/app/seed.py).
export const MENU_ITEMS: Record<string, MenuItem> = {
  chicken_original: {
    id: "chicken_original",
    name: "Original Recipe Chicken (pc)",
    prepMinutes: 18,
    parLevel: 60,
    unit: "pieces",
    dailyVolume: 420,
    sellThroughPerMin: 0.62,
  },
  corn_cup: {
    id: "corn_cup",
    name: "Corn Cup",
    prepMinutes: 4,
    parLevel: 40,
    unit: "cups",
    dailyVolume: 260,
    sellThroughPerMin: 0.58,
  },
  fries_reg: {
    id: "fries_reg",
    name: "Regular Fries",
    prepMinutes: 5,
    parLevel: 80,
    unit: "servings",
    dailyVolume: 500,
    sellThroughPerMin: 1.1,
  },
  beverage_cola: {
    id: "beverage_cola",
    name: "Cola (Reg)",
    prepMinutes: 1,
    parLevel: 100,
    unit: "cups",
    dailyVolume: 600,
    sellThroughPerMin: 1.4,
  },
};

export const WATCHED_RUNOUT_ITEMS = ["chicken_original", "corn_cup"];
