"""Idempotent seeding of the single PeaKit demo store, menu, and inventory.

We chose SQLAlchemy's `Base.metadata.create_all()` for schema creation plus
this hand-written idempotent seed function, rather than raw Flyway-style SQL
migration files. Rationale (documented in README): this is a hackathon
prototype with a schema that will not evolve independently of the ORM
models, so a migrations runner would be pure ceremony; `create_all()` +
"insert if not exists" seeding is the more idiomatic FastAPI/SQLAlchemy
choice for something this size, while still giving us the same guarantee the
Java Flyway scripts gave: a fresh database ends up in exactly the seeded
demo state.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.db import Base, SessionLocal, engine
from app.models import InventoryLevel, MenuItem, Store

DEMO_STORE_ID = "IN-BLR-0142"
SEED_SIM_TIME = datetime(2026, 9, 18, 13, 34, 0, tzinfo=timezone.utc)  # Fri 2026-09-18 19:04 IST

MENU_ITEMS = [
    dict(
        item_id="chicken_original",
        name="Original Recipe Chicken (pc)",
        prep_minutes=18,
        par_level=60,
        unit="pieces",
        daily_volume=420,
        sell_through_per_min=0.62,
    ),
    dict(
        item_id="corn_cup",
        name="Corn Cup",
        prep_minutes=4,
        par_level=40,
        unit="cups",
        daily_volume=260,
        sell_through_per_min=0.58,
    ),
    dict(
        item_id="fries_reg",
        name="Regular Fries",
        prep_minutes=5,
        par_level=80,
        unit="servings",
        daily_volume=500,
        sell_through_per_min=1.10,
    ),
    dict(
        item_id="beverage_cola",
        name="Cola (Reg)",
        prep_minutes=1,
        par_level=100,
        unit="cups",
        daily_volume=600,
        sell_through_per_min=1.40,
    ),
]

INITIAL_ON_HAND = {
    "chicken_original": 28,
    "corn_cup": 17,
    "fries_reg": 64,
    "beverage_cola": 210,
}


def seed_demo_data(db: Session) -> None:
    store = db.get(Store, DEMO_STORE_ID)
    if store is None:
        store = Store(
            store_id=DEMO_STORE_ID,
            name="PeaKit Demo Kitchen — Koramangala",
            timezone="Asia/Kolkata",
            weather="clear",
            sim_time_override=SEED_SIM_TIME,
        )
        db.add(store)

    for spec in MENU_ITEMS:
        item = db.get(MenuItem, spec["item_id"])
        if item is None:
            db.add(MenuItem(**spec))

    db.flush()

    for item_id, on_hand in INITIAL_ON_HAND.items():
        existing = (
            db.query(InventoryLevel)
            .filter(InventoryLevel.store_id == DEMO_STORE_ID, InventoryLevel.item_id == item_id)
            .one_or_none()
        )
        if existing is None:
            db.add(InventoryLevel(store_id=DEMO_STORE_ID, item_id=item_id, on_hand=on_hand))

    db.commit()


def reset_demo_data(db: Session) -> None:
    """Used by POST /stores/{id}/reset: puts sim clock, weather, and
    inventory back to the seed values without touching the audit log."""
    store = db.get(Store, DEMO_STORE_ID)
    if store is not None:
        store.sim_time_override = SEED_SIM_TIME
        store.weather = "clear"

    for item_id, on_hand in INITIAL_ON_HAND.items():
        row = (
            db.query(InventoryLevel)
            .filter(InventoryLevel.store_id == DEMO_STORE_ID, InventoryLevel.item_id == item_id)
            .one_or_none()
        )
        if row is not None:
            row.on_hand = on_hand

    db.commit()


def init_db_and_seed() -> None:
    """Create tables (if missing) and seed the demo store. Called at
    application startup."""
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_demo_data(db)
    finally:
        db.close()
