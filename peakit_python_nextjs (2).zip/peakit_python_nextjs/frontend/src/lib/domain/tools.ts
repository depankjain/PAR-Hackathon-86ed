/**
 * Deterministic tools — the TypeScript mirror of tools.py.
 *
 * Every function here is deliberately "boring": it reads from StoreState
 * and does arithmetic, nothing else. This is what the reasoning layer
 * (agent.ts, or Bedrock/Claude in production) is allowed to call — it is
 * NOT allowed to compute these numbers itself. See docs/ARCHITECTURE.md
 * section 2 for why that separation matters.
 *
 * Each function's docstring names the real PAR system it stands in for —
 * the same mapping used by the Python (FastAPI) backend's controllers, so the
 * mock and the real backend agree on both the contract AND the intent.
 */

import { MENU_ITEMS } from "./menu";
import { StoreState } from "./storeState";
import { expectedUnitsInWindow } from "./demand";

export interface ToolCall {
  toolName: string;
  sourceSystem: string;
  inputs: Record<string, unknown>;
  output: Record<string, unknown>;
  calledAt: string;
}

// Per-store audit log — mirrors tools.py's module-level TOOL_CALL_LOG, but
// keyed by store so concurrent requests for different stores don't cross
// their audit trails. Cleared per request by resetToolLog(), same as the
// Python prototype's reset_tool_log().
const auditLogs = new Map<string, ToolCall[]>();

function log(storeId: string, toolName: string, sourceSystem: string, inputs: Record<string, unknown>, output: Record<string, unknown>): ToolCall {
  const call: ToolCall = { toolName, sourceSystem, inputs, output, calledAt: new Date().toISOString() };
  if (!auditLogs.has(storeId)) auditLogs.set(storeId, []);
  auditLogs.get(storeId)!.push(call);
  return call;
}

export function resetToolLog(storeId: string) {
  auditLogs.set(storeId, []);
}

export function getToolLog(storeId: string): ToolCall[] {
  return auditLogs.get(storeId) ?? [];
}

/** Tool: item-level demand forecast. Production source: PAR OPS Forecasting. */
export function forecastDemand(state: StoreState, itemId: string, windowMinutes: number) {
  const predicted = expectedUnitsInWindow(itemId, state.simTime, windowMinutes, state.weather);
  const output = { itemId, windowMinutes, predictedUnits: predicted };
  return log(state.storeId, "forecast_demand", "PAR OPS — Forecasting", { itemId, windowMinutes }, output);
}

/** Tool: current on-hand stock. Production source: PAR OPS Inventory. */
export function getInventoryLevel(state: StoreState, itemId: string) {
  const onHand = state.inventory[itemId] ?? 0;
  const output = { itemId, onHand, unit: MENU_ITEMS[itemId]?.unit ?? "units" };
  return log(state.storeId, "get_inventory_level", "PAR OPS — Inventory", { itemId }, output);
}

/** Tool: minutes until an item runs out at the current sell-through rate.
 *  Production source: PAR OPS Inventory + PAR POS sell-through. */
export function predictRunout(state: StoreState, itemId: string) {
  const onHand = state.inventory[itemId] ?? 0;
  const rate = MENU_ITEMS[itemId]?.sellThroughPerMin ?? 0;
  const minutesToRunout = rate > 0 ? Math.round((onHand / rate) * 10) / 10 : Infinity;
  const output = { itemId, onHand, sellThroughPerMin: rate, minutesToRunout };
  return log(state.storeId, "predict_runout", "PAR OPS Inventory + PAR POS sell-through", { itemId }, output);
}

/** Tool: units that must be prepped now to cover forecast demand, net of stock.
 *  Composes forecastDemand() — that inner call is logged too. */
export function requiredPrepForWindow(state: StoreState, itemId: string, windowMinutes: number) {
  const forecastCall = forecastDemand(state, itemId, windowMinutes);
  const predicted = forecastCall.output.predictedUnits as number;
  const onHand = state.inventory[itemId] ?? 0;
  const shortfall = Math.max(0, Math.round((predicted - onHand) * 10) / 10);
  const output = { itemId, windowMinutes, predictedUnits: predicted, onHand, shortfallUnits: shortfall };
  return log(state.storeId, "required_prep_for_window", "PAR OPS Forecasting + Inventory", { itemId, windowMinutes }, output);
}

/** Tool: fires a restock/prep reminder into the kitchen task queue.
 *  The one WRITE action in this module — production source: PAR OPS Task Queue / KDS. */
export function createRestockReminder(state: StoreState, itemId: string, quantityHint: number | null) {
  const output = { itemId, quantityHint, status: "reminder_created" };
  return log(state.storeId, "create_restock_reminder", "PAR OPS — Task Queue / KDS", { itemId, quantityHint }, output);
}
