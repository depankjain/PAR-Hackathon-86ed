import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // "standalone" produces a self-contained server bundle (.next/standalone)
  // with only the node_modules it actually needs traced in — exactly what
  // ../Dockerfile's runtime stage copies, instead of shipping the whole
  // node_modules tree into the container image.
  output: "standalone",
};

export default nextConfig;
