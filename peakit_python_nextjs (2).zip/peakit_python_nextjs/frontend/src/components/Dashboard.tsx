"use client";

import { MENU_ITEMS } from "@/lib/domain/menu";
import { StoreStateDto } from "@/lib/types";

function InventoryCard({ itemId, state }: { itemId: string; state: StoreStateDto }) {
  const item = MENU_ITEMS[itemId];
  const onHand = state.inventory[itemId] ?? 0;
  const pct = Math.max(4, Math.min(100, (onHand / item.parLevel) * 100));
  const low = pct < 50;
  const minutesToRunout = item.sellThroughPerMin > 0 ? onHand / item.sellThroughPerMin : null;

  return (
    <div className="rounded-2xl bg-white border border-slate-200 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-semibold text-slate-800">{item.name}</span>
        <span className="text-xs text-slate-400">par {item.parLevel}</span>
      </div>
      <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden mb-2">
        <div
          className={`h-full rounded-full ${low ? "bg-gradient-to-r from-amber-500 to-red-500" : "bg-gradient-to-r from-indigo-500 to-indigo-400"}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>{Math.round(onHand)} {item.unit} on hand</span>
        {minutesToRunout !== null && <span>~{Math.round(minutesToRunout)} min to runout</span>}
      </div>
    </div>
  );
}

export default function Dashboard({
  state,
  onAdvance,
  onReset,
  loading,
}: {
  state: StoreStateDto | null;
  onAdvance: () => void;
  onReset: () => void;
  loading: boolean;
}) {
  if (!state) {
    return <div className="rounded-2xl bg-white border border-slate-200 p-8 text-slate-400 text-sm">Loading live store signals…</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold uppercase tracking-wide text-slate-500">Live Store Signals</h2>
        <div className="flex gap-2">
          <button
            onClick={onAdvance}
            disabled={loading}
            className="text-xs font-semibold rounded-full bg-slate-100 hover:bg-slate-200 px-3 py-1.5 text-slate-700 disabled:opacity-50"
          >
            Advance 15 min ▸
          </button>
          <button
            onClick={onReset}
            disabled={loading}
            className="text-xs font-semibold rounded-full bg-slate-100 hover:bg-slate-200 px-3 py-1.5 text-slate-700 disabled:opacity-50"
          >
            Reset
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <InventoryCard itemId="chicken_original" state={state} />
        <InventoryCard itemId="corn_cup" state={state} />
        <InventoryCard itemId="fries_reg" state={state} />
        <InventoryCard itemId="beverage_cola" state={state} />
      </div>

      <div className="rounded-2xl bg-indigo-950 text-indigo-100 p-5 text-xs leading-relaxed">
        <span className="font-bold text-white">Why this is auditable — </span>
        every number here and every PeaKit reply comes from a named tool call against a stand-in for a real
        PAR system. Nothing is generated freeform by a model. See the trail under each answer.
      </div>
    </div>
  );
}
