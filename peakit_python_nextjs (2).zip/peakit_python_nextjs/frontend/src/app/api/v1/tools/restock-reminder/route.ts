import { NextRequest, NextResponse } from "next/server";
import { resolveState } from "@/lib/domain/requestHelpers";
import { createRestockReminder } from "@/lib/domain/tools";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const state = resolveState(body);
  const call = createRestockReminder(state, body.itemId, body.quantityHint ?? null);
  return NextResponse.json(call.output);
}
