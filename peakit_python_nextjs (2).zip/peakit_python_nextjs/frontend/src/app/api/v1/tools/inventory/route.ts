import { NextRequest, NextResponse } from "next/server";
import { resolveState } from "@/lib/domain/requestHelpers";
import { getInventoryLevel } from "@/lib/domain/tools";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const state = resolveState(body);
  const call = getInventoryLevel(state, body.itemId);
  return NextResponse.json(call.output);
}
