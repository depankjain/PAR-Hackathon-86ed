"""Builds the StoreState wire representation and applies the sim-clock
advance logic (fast-forward + decrement on-hand by sell-through rate)."""
from __future__ import annotations

from datetime import timedelta
from typing import Any

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import InventoryLevel, MenuItem, Store
from app.services.time_utils import to_iso_utc_z


def _get_store_or_404(db: Session, store_id: str) -> Store:
    store = db.get(Store, store_id)
    if store is None:
        raise HTTPException(status_code=404, detail=f"Unknown store '{store_id}'")
    return store


def build_state(db: Session, store_id: str) -> dict[str, Any]:
    store = _get_store_or_404(db, store_id)
    rows = db.execute(
        select(InventoryLevel).where(InventoryLevel.store_id == store_id)
    ).scalars().all()

    inventory = {row.item_id: row.on_hand for row in rows}
    sim_time_iso = to_iso_utc_z(store.sim_time_override)

    return {
        "storeId": store.store_id,
        "storeName": store.name,
        "simTime": sim_time_iso,
        "weather": store.weather,
        "inventory": inventory,
    }


def advance(db: Session, store_id: str, minutes: int) -> dict[str, Any]:
    store = _get_store_or_404(db, store_id)
    store.sim_time_override = store.sim_time_override + timedelta(minutes=minutes)

    rows = db.execute(
        select(InventoryLevel).where(InventoryLevel.store_id == store_id)
    ).scalars().all()
    for row in rows:
        item = db.get(MenuItem, row.item_id)
        rate = item.sell_through_per_min if item else 0.0
        depleted = row.on_hand - (rate * minutes)
        row.on_hand = round(max(0.0, depleted), 1)

    db.commit()
    return build_state(db, store_id)
