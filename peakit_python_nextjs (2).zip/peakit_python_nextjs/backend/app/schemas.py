"""Pydantic v2 request/response schemas.

All wire field names are camelCase to match the shared OpenAPI contract used
by both this Python backend and the Java reference implementation, so the
Next.js frontend can talk to either interchangeably.

We keep Python-side attribute names snake_case (idiomatic) and expose the
camelCase wire names via `alias=`. `populate_by_name=True` lets us also
construct these models from Python using the snake_case kwargs, and
`ConfigDict(populate_by_name=True)` combined with FastAPI's default
`response_model_by_alias=True` means responses are serialized using the
camelCase aliases.
"""
from __future__ import annotations

from typing import Any, Union

from pydantic import BaseModel, ConfigDict, Field

CAMEL_CONFIG = ConfigDict(populate_by_name=True)


# ---------------------------------------------------------------------------
# Store state
# ---------------------------------------------------------------------------


class StoreState(BaseModel):
    model_config = CAMEL_CONFIG

    store_id: str = Field(alias="storeId")
    store_name: str = Field(alias="storeName")
    sim_time: str = Field(alias="simTime")
    weather: str
    inventory: dict[str, float]


class AdvanceRequest(BaseModel):
    model_config = CAMEL_CONFIG

    minutes: int


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


class ToolCall(BaseModel):
    model_config = CAMEL_CONFIG

    tool_name: str = Field(alias="toolName")
    source_system: str = Field(alias="sourceSystem")
    inputs: dict[str, Any]
    output: dict[str, Any]
    called_at: str = Field(alias="calledAt")


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


class ForecastRequest(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    window_minutes: int = Field(alias="windowMinutes")


class ForecastResponse(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    window_minutes: int = Field(alias="windowMinutes")
    predicted_units: float = Field(alias="predictedUnits")


class ItemRequest(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")


class InventoryResponse(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    on_hand: float = Field(alias="onHand")
    unit: str


class RunoutResponse(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    on_hand: float = Field(alias="onHand")
    sell_through_per_min: float = Field(alias="sellThroughPerMin")
    # No native JSON Infinity: when sell-through is 0 we serialize the
    # string "Infinity" rather than a numeric sentinel. Documented in README.
    minutes_to_runout: Union[float, str] = Field(alias="minutesToRunout")


class RequiredPrepResponse(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    window_minutes: int = Field(alias="windowMinutes")
    predicted_units: float = Field(alias="predictedUnits")
    on_hand: float = Field(alias="onHand")
    shortfall_units: float = Field(alias="shortfallUnits")


class RestockReminderRequest(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    quantity_hint: float | None = Field(default=None, alias="quantityHint")


class RestockReminderResponse(BaseModel):
    model_config = CAMEL_CONFIG

    item_id: str = Field(alias="itemId")
    quantity_hint: float | None = Field(alias="quantityHint")
    status: str = "reminder_created"


# ---------------------------------------------------------------------------
# Agent orchestration
# ---------------------------------------------------------------------------


class AgentAskRequest(BaseModel):
    model_config = CAMEL_CONFIG

    store_id: str = Field(alias="storeId")
    query: str


class AgentAskResponse(BaseModel):
    model_config = CAMEL_CONFIG

    query: str
    intent: str
    recommendation: str
    tool_calls: list[ToolCall] = Field(alias="toolCalls")
