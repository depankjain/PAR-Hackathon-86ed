import { NextRequest, NextResponse } from "next/server";
import { advanceClock } from "@/lib/domain/storeState";

// POST /api/v1/stores/{storeId}/advance
// Demo/testing only — advances the simulated clock and consumes inventory
// at each item's current sell-through rate. Has no equivalent against a
// real store; the real backend does not implement this endpoint at all.
export async function POST(req: NextRequest, { params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  const body = await req.json().catch(() => ({}));
  const minutes = typeof body.minutes === "number" ? body.minutes : 15;
  const state = advanceClock(storeId, minutes);
  return NextResponse.json({
    storeId: state.storeId,
    storeName: state.storeName,
    simTime: state.simTime.toISOString(),
    weather: state.weather,
    inventory: state.inventory,
  });
}
