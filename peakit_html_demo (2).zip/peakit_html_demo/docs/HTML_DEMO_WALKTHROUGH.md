# PeaKit — Standalone HTML Demo: Full Walkthrough

This document explains `index.html` — the single, self-contained file in `peakit_html_demo/` — from top to bottom. It has zero dependencies, zero build step, and zero server: opening the file in a browser is the entire "installation." Everything you see move on screen is produced by inline JavaScript acting on an in-memory JavaScript object; nothing here talks to a network, a database, or a real PAR system.

---

## Part 0 — Why this file exists at all

The main PeaKit project has a real, buildable stack (`peakit_python_nextjs/` or `peakit_fullstack/`) with a real backend and a real database. That's the right thing to *build*, but it's the wrong thing to hand a judge or stakeholder who just wants to click around for two minutes without running `npm install`, `docker compose up`, or anything else. This file exists purely to solve that problem: one `.html` file, double-click it, it works, forever, offline. Everything it shows is a faithful *simulation* of what the real system does — same three capabilities (current stock, restock timing, demand forecast/footfall), same style of tool-call audit trail — just computed in the browser instead of a Postgres-backed FastAPI service.

---

## Part 1 — Document structure (lines 1–360)

### `<head>` and the `<style>` block (lines 1–276)

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```
Standard responsive-design meta tag — without it, mobile browsers render the page zoomed out as if it were a desktop-only site.

```css
:root{
  --indigo:#4F46E5;
  --slate-900:#0F172A;
  ...
}
```
CSS **custom properties** (variables), declared once on `:root` (the `<html>` element) and reused everywhere below as `var(--indigo)`, etc. This is the entire color palette for the page in one place — change a value here and every use of it updates. The palette itself (indigo primary, slate neutrals, green/amber/red status colors) matches the branding used elsewhere in the PeaKit project (the Next.js frontend, the pitch-deck mockups) so all three deliverables look like the same product.

```css
*{box-sizing:border-box;}
```
A near-universal CSS reset: makes an element's declared `width`/`height` include its padding and border, rather than adding them on top — without this, most manual pixel-based layouts drift and overflow unpredictably.

```css
main{
  display:grid;
  grid-template-columns:1.08fr 1fr;
  gap:22px;
}
@media (max-width:920px){
  main{grid-template-columns:1fr;}
}
```
CSS Grid lays the page out as two columns (the left one very slightly wider, `1.08fr` vs `1fr`, so the inventory panel gets a touch more breathing room than the chat panel). The `@media` query collapses that to a single column below 920px width, so the page remains usable on a narrow browser window or tablet — this is the entire "responsiveness" strategy for this file, deliberately simple since it's a demo, not a production UI.

The rest of the `<style>` block is straightforward component-level CSS: `.item-card` / `.bar-track` / `.bar-fill` style the inventory progress bars (with `.ok`/`.warn`/`.danger` modifier classes swapping the fill color); `.banner.restock` / `.banner.restock-ok` / `.banner.trust` style the three colored callout boxes; `.msg.manager` / `.msg.agent` style the chat bubbles (right-aligned indigo for the manager, left-aligned gray for PeaKit); `details.audit` styles the collapsible tool-call trail, including a hand-rolled expand/collapse arrow:

```css
details.audit summary:before{content:"▸";display:inline-block;transition:transform .15s;}
details.audit[open] summary:before{transform:rotate(90deg);}
```
The native `<details>`/`<summary>` HTML elements already provide expand/collapse behavior for free (no JavaScript needed for that part) — this CSS just replaces the browser's default disclosure triangle with a custom one that visibly rotates 90° when the `[open]` attribute is present, which the browser toggles automatically when the element is clicked.

### `<body>` — the visible structure (lines 277–359)

```html
<header class="top">...</header>
<div class="disclaimer">All store data, sales figures, and chat replies on this page are simulated / mock data...</div>
<main>
  <section class="panel"> ... Live Store Signals ... </section>
  <section class="panel chat-panel"> ... Ask PeaKit ... </section>
</main>
<footer class="bottom">...</footer>
```

This is the whole visual skeleton. Notice most of the interesting content areas are **empty containers with just an `id`**, filled in by JavaScript at load time and again every time something changes:

```html
<div class="items-grid" id="itemsGrid"></div>
<div id="restockBanner"></div>
<ul class="fc-list" id="fcList"></ul>
<div class="chat-log" id="chatLog"></div>
<div class="chips" id="chips"></div>
```

This is a deliberate, simple pattern: the HTML defines *where* things go and what they're styled as; the JavaScript below decides *what* actually appears there, and re-renders those five containers' `innerHTML` every time the underlying state changes (a button click, a clock advance, a new chat message).

---

## Part 2 — The JavaScript, section by section (lines 360–792)

Everything lives inside one **immediately-invoked function expression** (IIFE):

```javascript
(function(){
  "use strict";
  ... everything ...
})();
```

Wrapping the entire script in `(function(){ ... })()` means every variable and function declared inside it is private to this script — it can't accidentally collide with some other script's global variables (not a real risk here since this is the only script on the page, but it's a standard, harmless habit). `"use strict"` turns on JavaScript's stricter error-checking mode (e.g. it turns silent typos like assigning to an undeclared variable into a thrown error instead of quietly creating a global).

### 2.1 Seed data (lines 367–393)

```javascript
var SEED_ITEMS = [
  { id:"chicken", name:"Original Recipe Chicken", unit:"pieces", stock:48, par:60, baseSellPerHour:5, leadTimeHours:3, aliases:[...] },
  { id:"corn", name:"Corn Cup", unit:"cups", stock:34, par:45, baseSellPerHour:3.5, leadTimeHours:2, aliases:[...] },
  ...
];
var BASE_FOOTFALL_PER_HOUR = 45;

function cloneSeed(){
  return SEED_ITEMS.map(function(it){ return {...}; });  // deep-ish copy
}

function freshSimTime(){
  var d = new Date();
  d.setHours(11,0,0,0);  // demo scenario starts at 11:00 AM
  return d;
}

var state = { items: cloneSeed(), simTime: freshSimTime() };
```

`state` is the **single source of truth** for the whole page — one JavaScript object holding the current stock/par/lead-time for five menu items, plus the simulated "current time." Every render function below reads from `state`; every user action mutates `state` and then re-renders. This is a much smaller-scale version of the exact same pattern the real backend uses (a `Store` + `MenuItem` + `InventoryLevel` set of database rows) and the Next.js mock uses (an in-memory `Map`) — same idea, simplest possible implementation for a single static HTML file.

`cloneSeed()` exists specifically so the "Reset" button can restore the *original* seed values without them having been mutated by earlier "Advance" clicks — if `state.items` were a direct reference to `SEED_ITEMS`, every advance would permanently corrupt the one seed array and Reset would have nothing correct left to restore.

Five items here, slightly different from the seeded data in the Python/Next.js projects (fries in "lbs" instead of "servings", a "Biscuits" item added, `baseSellPerHour` instead of `sellThroughPerMin`) — this file's seed data was authored independently for this standalone demo rather than sharing a data file with the other two projects, since there is no shared module system between a single static HTML file and the rest of the codebase.

### 2.2 The demand model (lines 396–458)

```javascript
function demandMultiplier(date){
  var h = hourFloat(date);
  if (h >= 11 && h < 13) return 1.6;  // lunch rush
  if (h >= 17 && h < 19) return 1.8;  // dinner rush
  if (h >= 21 || h < 6)  return 0.4;  // late night / overnight
  return 1.0;
}
```

This is this file's own, simpler version of the "demand forecasting" idea — instead of the hour-by-hour weight table + day-of-week multiplier + weather modifier used in the Python/Next.js/Java implementations, this demo uses one flat multiplier per daypart (lunch/dinner/overnight/normal). It's intentionally lighter-weight: this file's job is to *look and feel* right for a two-minute click-through, not to reproduce the production forecasting formula exactly.

```javascript
function currentSellRate(item, date){ return item.baseSellPerHour * demandMultiplier(date); }
function runoutHours(item, date){
  var rate = currentSellRate(item, date);
  if (rate <= 0) return Infinity;
  return item.stock / rate;
}
function needsRestock(item, date){
  var h = runoutHours(item, date);
  return h <= item.leadTimeHours || item.stock <= item.par * 0.2;
}
function statusLevel(item, date){
  var pctPar = item.stock / item.par;
  var h = runoutHours(item, date);
  if (pctPar <= 0.25 || h <= item.leadTimeHours) return "danger";
  if (pctPar <= 0.5 || h <= item.leadTimeHours * 1.5) return "warn";
  return "ok";
}
```

These four functions are the entire "brain" behind the left-hand panel:
- `currentSellRate` — units per hour right now, given the current simulated time-of-day.
- `runoutHours` — how many hours of stock remain at that rate (real `Infinity`, JavaScript's built-in value for "divide by zero," used directly — this is one difference from the Python backend, which can't use a real JSON `Infinity` and sends the *string* `"Infinity"` instead; this file never serializes anything to JSON, so it doesn't need that workaround).
- `needsRestock` — true if runway is inside the item's restock lead time, *or* stock has dropped to 20% of par regardless of lead time (a safety-net condition for slow-moving items with a short lead time that might otherwise never trigger the first check).
- `statusLevel` — turns the same numbers into one of three UI colors (`"ok"`/`"warn"`/`"danger"`), using slightly looser thresholds than `needsRestock` (1.5× lead time, 50% of par) so the amber "getting close" warning shows up before the harder red "act now" state does.

`fmtDuration`, `fmtClock`, `etaClockFromNow`, and `round1` are small formatting helpers — turning a raw hour count into `"1h 12m"`, formatting a `Date` as a localized clock time, computing what wall-clock time a runout will happen at, and rounding to one decimal place, respectively.

### 2.3 Rendering (lines 461–536)

```javascript
var els = {
  storeTime: document.getElementById("storeTime"),
  itemsGrid: document.getElementById("itemsGrid"),
  ...
};
```

Every DOM element the script needs to touch is looked up **once**, up front, and cached in the `els` object — rather than calling `document.getElementById(...)` again every time a render happens. Cheap for a page this small, but it's the correct habit for any script that re-renders frequently.

```javascript
function renderItemsGrid(){
  var html = "";
  state.items.forEach(function(item){
    var pct = Math.max(0, Math.min(100, Math.round((item.stock / item.par) * 100)));
    var level = statusLevel(item, state.simTime);
    var eta = fmtDuration(runoutHours(item, state.simTime));
    html += '<div class="item-card">' + ... + '</div>';
  });
  els.itemsGrid.innerHTML = html;
}
```

The rendering strategy throughout this file is **string concatenation into `innerHTML`**: build one big HTML string in a loop, then assign it to a container's `.innerHTML` exactly once. This is simple and fast enough for five items and a short chat log; a larger, longer-lived app would normally reach for a framework (React, as the real Next.js frontend does) specifically to avoid the bookkeeping problems this pattern causes at scale (losing focus/scroll state, re-parsing HTML on every tiny change) — but for a five-item, click-a-button demo, plain string-building keeps the file dependency-free and completely transparent.

`renderRestockBanner()` filters `state.items` down to whichever ones `needsRestock()` flags, and renders either the green "no action needed" banner or the red "restock recommended" banner listing each flagged item's runway and lead time.

`renderForecast()` computes the *next* hour's multiplier (not the current hour's — this deliberately looks one step ahead), projects a footfall number and a per-item expected sell-through quantity for that window, and fills in the "Next Hour Forecast" list.

`renderAll()` is the single function that calls all four render functions in sequence — every place in the script that changes `state` calls `renderAll()` immediately afterward, so the UI is always redrawn fully consistent with the current state. There's no partial-update logic anywhere; simplicity was chosen over efficiency, again because the whole state is only five items and one clock value.

### 2.4 Simulation controls (lines 539–557)

```javascript
function advance15Minutes(){
  var elapsedHours = 0.25;
  state.items.forEach(function(item){
    var rate = currentSellRate(item, state.simTime);
    var consumed = rate * elapsedHours;
    item.stock = Math.max(0, round1(item.stock - consumed));
  });
  state.simTime = new Date(state.simTime.getTime() + 15*60000);
  renderAll();
}
```

This is what the "Advance 15 min ▸" button does: for every item, compute how much would sell in a quarter hour at the *current* rate (which depends on the *current* time — importantly, this uses the sell rate *before* the clock moves, i.e. it assumes a constant rate across the 15-minute step rather than integrating a changing rate continuously; a reasonable simplification at 15-minute granularity), subtract that from stock (clamped at 0 so stock can never go negative), then actually move the clock forward by 15 minutes (`15*60000` milliseconds), then re-render everything.

`resetAll()` is the mirror image: restores `state.items` from a fresh `cloneSeed()`, restores `state.simTime` to the original 11:00 AM starting point, re-renders, and reseeds the chat log back to its initial single exchange (see 2.6).

### 2.5 "Ask PeaKit" — intent classification and reply generation (lines 560–702)

```javascript
var TOOLS = {
  stock:   { name:"get_current_stock",     source:"PAR OPS · Data Central (inventory feed)" },
  restock: { name:"create_restock_reminder", source:"PAR OPS · Data Central (ordering/inventory)" },
  forecast:{ name:"predict_runout",        source:"PAR POS · Brink (sell-through data)" }
};
```

This is the demo's version of the "which real PAR system would this come from in production" labeling used throughout the whole PeaKit project — every simulated tool call the chat shows is tagged with one of these `source` strings, so a viewer immediately sees the intended production data source even though this file is 100% offline.

```javascript
function findItem(text){
  var t = text.toLowerCase();
  for (var i = 0; i < state.items.length; i++){
    var item = state.items[i];
    if (t.indexOf(item.id) !== -1) return item;
    for (var j = 0; j < item.aliases.length; j++){
      if (t.indexOf(item.aliases[j]) !== -1) return item;
    }
  }
  return null;
}
```

A simple substring search: lower-case the question, then check whether it contains an item's internal `id` (like `"chicken"`) or any of its listed `aliases` (like `"ofc"`, `"fried chicken"`, `"original recipe"`). This lets a manager type something conversational — "how's the fried chicken looking?" — and still match the `chicken` item, without needing exact wording. It's not sophisticated (it can't handle typos, and it always matches the *first* item whose alias appears anywhere in the sentence), but it's transparent and easy to extend by just adding more strings to an `aliases` array.

```javascript
function classifyIntent(text){
  var t = text.toLowerCase();
  if (/restock|reorder|order more|when.*(buy|order)|need.*(order|restock)/.test(t)) return "restock";
  if (/run ?out|runout|out of|last (until|how long)|tonight|how long/.test(t)) return "runout";
  if (/busy|footfall|forecast|rush|guests|customers|how many people|next hour/.test(t)) return "forecast";
  if (/stock|left|remaining|how much|on hand|inventory/.test(t)) return "stock";
  return "unknown";
}
```

Four regular expressions, checked in a fixed priority order (`restock` is checked before `stock`, deliberately, so a question like "when should I restock the corn cups?" — which contains the substring `"stock"` — correctly matches `restock` and not the more generic `stock` intent, since `restock` is tested first and returns immediately). This is the same "keyword-matching stand-in for a real AI call" idea as `classify_local()` in the Python backend and `routeIntent()` in the Next.js mock — same spirit, independently written for this standalone file since (again) there's no shared module to import from here.

`buildReply(rawText)` is the largest function in the file — it finds the item, classifies the intent, and then has one `if`/`else if` branch per intent (`"stock"`, `"runout"`, `"restock"`, `"forecast"`), each of which:
1. Pushes one or more entries into a `calls` array (each with a `tool` name, a `source` system, `args`, and a `result`) — this becomes the audit trail shown under the chat reply.
2. Builds a `reply` string using the actual current numbers from `state` (never a canned, static sentence) — so, for example, asking about chicken stock at a different simulated time (after clicking Advance a few times) genuinely produces a different percentage and a different runway estimate, computed live from whatever `state.items` currently holds.

The `"runout"` branch is the most elaborate, mirroring the real backend's `_handle_runout_check` logic in spirit: it looks up current stock, computes a runout ETA, and — only if that ETA falls inside the item's restock lead time — adds a third tool call actually "creating" a restock reminder and says so in the reply; otherwise it explicitly says no action is needed yet. This if/else structure (state the numbers, then explain the *decision* that follows from them) is the same shape as every "answer" in this whole project, at every layer of the stack.

### 2.6 Chat rendering and wiring (lines 705–789)

```javascript
function appendMessage(role, text, calls){
  var wrap = document.createElement("div");
  wrap.className = "msg " + role;
  ...
  if (calls && calls.length){
    var details = document.createElement("details");
    details.className = "audit";
    var summary = document.createElement("summary");
    summary.textContent = "Tool-call audit trail (" + calls.length + " tool" + (calls.length > 1 ? "s" : "") + " invoked)";
    details.appendChild(summary);
    var body = document.createElement("div");
    body.innerHTML = calls.map(auditCallHTML).join("");
    details.appendChild(body);
    wrap.appendChild(details);
  }
  els.chatLog.appendChild(wrap);
  els.chatLog.scrollTop = els.chatLog.scrollHeight;
}
```

Unlike the earlier render functions (which rebuild a whole container's `innerHTML` from scratch every time), chat messages are **appended** one at a time using `document.createElement`/`appendChild` — this is the one place in the file using the DOM API directly instead of string concatenation, because appending is the natural operation here (you never want to erase and rebuild the entire chat history just to add one new message). The collapsible tool-call trail is built from a real `<details>`/`<summary>` pair (giving free expand/collapse behavior, as noted in Part 1), pluralizing "tool"/"tools" correctly based on `calls.length`. The final line, setting `scrollTop = scrollHeight`, is what auto-scrolls the chat log down to the newest message.

```javascript
function askQuestion(text){
  text = (text || "").trim();
  if (!text) return;
  appendMessage("manager", text, null);
  var result = buildReply(text);
  window.setTimeout(function(){
    appendMessage("agent", result.reply, result.calls);
  }, 220);
  els.askInput.value = "";
}
```

The manager's message appears immediately; the agent's reply is deliberately delayed by 220 milliseconds via `window.setTimeout` — purely cosmetic, so the exchange feels like a real back-and-forth round trip to a server rather than an instantaneous, obviously-fake calculation. `buildReply` itself runs synchronously and finishes well within that delay; nothing is actually waiting on anything.

```javascript
document.getElementById("advanceBtn").addEventListener("click", advance15Minutes);
document.getElementById("resetBtn").addEventListener("click", resetAll);
document.getElementById("askBtn").addEventListener("click", function(){ askQuestion(els.askInput.value); });
els.askInput.addEventListener("keydown", function(e){ if (e.key === "Enter") askQuestion(els.askInput.value); });
els.chips.addEventListener("click", function(e){
  var target = e.target.closest(".chip");
  if (!target) return;
  askQuestion(target.getAttribute("data-q"));
});
```

Standard event wiring: the two simulation buttons, the Ask button, the Enter key inside the text input, and — using **event delegation** — a single click listener on the whole `.chips` container rather than one listener per suggestion chip. `e.target.closest(".chip")` walks up from whatever element was actually clicked to find the nearest ancestor (or itself) matching `.chip`; this means new chips could be added or removed later without ever needing to re-attach listeners, because the one listener on the parent container handles all of them, present or future.

```javascript
renderChips();
renderAll();
seedChatLog();
```

The very last three lines of the script — run once, immediately, as soon as the script executes (there's no "wait for page load" event needed here, because the `<script>` tag sits at the very end of `<body>`, after every element it references already exists in the DOM). `renderChips()` fills in the three suggested-question buttons; `renderAll()` does the first paint of the inventory grid, restock banner, and forecast list; `seedChatLog()` clears the chat log and immediately asks (and answers) one pre-written question — "Will we run out of chicken before dinner rush?" — through the exact same `buildReply()` logic a real typed question would use, so the page never opens on an empty, uninteresting chat panel.

---

## Part 3 — What's simulated vs. what mirrors the real system

| In this file | In the real backend (`peakit_python_nextjs`) |
|---|---|
| One JS object (`state`), lost on page refresh | Postgres tables (`stores`, `menu_items`, `inventory_levels`) |
| `classifyIntent()` — 4 regexes | `AiReasoningPort` — local keyword stub, or a real AWS Bedrock/Claude call |
| `calls` array, shown once, never saved | `tool_call_audit_log` table, persisted and queryable via `GET /audit-log` |
| Flat daypart multiplier (`demandMultiplier`) | Hour-of-day weight table × day-of-week multiplier × weather modifier |
| `"PAR POS · Brink"` / `"PAR OPS · Data Central"` labels, purely cosmetic | The actual integration this labeling promises — see the companion Brink POS integration document |

Everything in the left column exists to make the right column's *idea* visible and clickable in under a minute, with nothing to install.
