"""Pytest collection hook: pin DATABASE_URL to a throwaway SQLite file
*before* any test module imports `app.db` / `app.config`, since
`get_settings()` is `lru_cache`d and only reads the environment once.

Real Postgres is not available in this sandbox - see README for what was
and wasn't verified against a live Postgres instance.
"""
import os
import tempfile

_fd, _path = tempfile.mkstemp(suffix=".db", prefix="peakit_conftest_")
os.close(_fd)
os.environ.setdefault("DATABASE_URL", f"sqlite:///{_path}")
os.environ.setdefault("PEAKIT_AI_PROVIDER", "local")
