/**
 * Demand-forecasting formula — the TypeScript mirror of
 * synthetic_data.py's expected_units_in_window(). Same shape of inputs,
 * same shape of output, minus the cosmetic sine-wave noise term (left out
 * here for simplicity, exactly as it was in the browser demo in the
 * original Python-based prototype).
 *
 * Production note: this whole file is replaced by a real call to PAR OPS
 * Forecasting. It is NOT a candidate for delegating to Bedrock/Claude —
 * forecasting stays a deterministic calculation so it can be audited,
 * per the tool-calling design in the architecture doc.
 */

import { MENU_ITEMS } from "./menu";

export const BASE_HOURLY_WEIGHTS: Record<number, number> = {
  11: 0.06, 12: 0.1, 13: 0.09, 14: 0.05, 15: 0.03, 16: 0.03,
  17: 0.05, 18: 0.09, 19: 0.14, 20: 0.16, 21: 0.12, 22: 0.08,
};

// Keyed by JavaScript's Date.getDay(): 0 = Sunday ... 6 = Saturday.
// (Python's datetime.weekday() is Monday-first; see the docx walkthrough
// for why the mapping differs between the two prototypes.)
export const DAY_OF_WEEK_MULTIPLIER: Record<number, number> = {
  0: 1.1,   // Sun
  1: 0.85,  // Mon
  2: 0.85,  // Tue
  3: 0.9,   // Wed
  4: 0.95,  // Thu
  5: 1.25,  // Fri  <- surge day used in the demo scenario
  6: 1.35,  // Sat
};

export const WEATHER_MODIFIERS: Record<string, number> = {
  clear: 1.0,
  rain: 1.18,
  heatwave: 0.92,
};

export function expectedUnitsInWindow(
  itemId: string,
  at: Date,
  windowMinutes: number,
  weather: string = "clear"
): number {
  const hour = at.getHours();
  const weight = BASE_HOURLY_WEIGHTS[hour] ?? 0.02;
  const dowMult = DAY_OF_WEEK_MULTIPLIER[at.getDay()];
  const weatherMult = WEATHER_MODIFIERS[weather] ?? 1.0;
  const dailyVolume = MENU_ITEMS[itemId].dailyVolume;

  const hourlyUnits = dailyVolume * weight * dowMult * weatherMult;
  const fractionOfHour = windowMinutes / 60;
  const predicted = hourlyUnits * fractionOfHour;
  return Math.round(predicted * 10) / 10;
}
