/** Types mirroring api-contract/openapi.yaml. Shared by the API client and
 * every UI component — kept in one place so the frontend and (conceptually)
 * the Python (Pydantic) schemas never drift apart. */

export interface StoreStateDto {
  storeId: string;
  storeName: string;
  simTime: string; // ISO-8601
  weather: string;
  inventory: Record<string, number>;
}

export interface ToolCallDto {
  toolName: string;
  sourceSystem: string;
  inputs: Record<string, unknown>;
  output: Record<string, unknown>;
  calledAt: string;
}

export interface AgentAskResponseDto {
  query: string;
  intent: string;
  toolCalls: ToolCallDto[];
  recommendation: string;
}
