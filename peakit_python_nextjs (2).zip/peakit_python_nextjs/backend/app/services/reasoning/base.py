"""The AI-reasoning seam.

Both the local keyword-matching stub and the real Bedrock adapter implement
this interface, so `orchestration.py` doesn't know or care which one
answered a given query.
"""
from __future__ import annotations

from typing import Protocol

# Intent values (upper snake case internally; the API surfaces the lowercase
# snake_case form, e.g. "runout_check").
RUNOUT_CHECK = "RUNOUT_CHECK"
FORECAST_CHECK = "FORECAST_CHECK"
GENERAL_STATUS = "GENERAL_STATUS"

VALID_INTENTS = {RUNOUT_CHECK, FORECAST_CHECK, GENERAL_STATUS}


class AiReasoningPort(Protocol):
    """Classifies a free-text store-manager query into one of the three
    supported intents."""

    def classify_intent(self, query: str) -> str:
        ...
