"""Real AWS Bedrock adapter using the Converse API with forced native tool
use (a `classify_intent` tool with an `intent` enum parameter).

On ANY exception - throttling, missing credentials, network error,
malformed response, whatever - we catch it, log a warning, and fall back to
the local keyword stub. A Bedrock outage must never break the endpoint.
"""
from __future__ import annotations

import logging

from app.config import get_settings
from app.services.reasoning.base import VALID_INTENTS
from app.services.reasoning.local_stub import classify_local

logger = logging.getLogger("peakit.reasoning.bedrock")

_CLASSIFY_TOOL = {
    "toolSpec": {
        "name": "classify_intent",
        "description": (
            "Classify a restaurant store manager's question into exactly one "
            "supported intent."
        ),
        "inputSchema": {
            "json": {
                "type": "object",
                "properties": {
                    "intent": {
                        "type": "string",
                        "enum": ["RUNOUT_CHECK", "FORECAST_CHECK", "GENERAL_STATUS"],
                        "description": (
                            "RUNOUT_CHECK: risk of an item running out soon. "
                            "FORECAST_CHECK: expected demand/sell-through. "
                            "GENERAL_STATUS: general current-stock question."
                        ),
                    }
                },
                "required": ["intent"],
            }
        },
    }
}


class BedrockReasoning:
    def __init__(self) -> None:
        settings = get_settings()
        self._model_id = settings.peakit_bedrock_model_id
        self._region = settings.aws_region
        self._client = None  # lazily created so import never requires AWS creds

    def _get_client(self):
        if self._client is None:
            import boto3

            self._client = boto3.client("bedrock-runtime", region_name=self._region)
        return self._client

    def classify_intent(self, query: str) -> str:
        try:
            client = self._get_client()
            response = client.converse(
                modelId=self._model_id,
                messages=[{"role": "user", "content": [{"text": query}]}],
                toolConfig={
                    "tools": [_CLASSIFY_TOOL],
                    "toolChoice": {"tool": {"name": "classify_intent"}},
                },
            )
            content_blocks = response["output"]["message"]["content"]
            for block in content_blocks:
                tool_use = block.get("toolUse")
                if tool_use and tool_use.get("name") == "classify_intent":
                    intent = tool_use["input"]["intent"]
                    if intent in VALID_INTENTS:
                        return intent
            raise ValueError(f"Bedrock response had no usable classify_intent tool call: {response}")
        except Exception as exc:  # noqa: BLE001 - intentionally broad, see module docstring
            logger.warning("Bedrock classify_intent failed (%s); falling back to local stub", exc)
            return classify_local(query)
