"""Pure-Python tests for the deterministic demand-forecast formula and the
local intent classifier - no database required."""
from datetime import datetime, timezone

from app.services.demand_forecast import expected_units_in_window
from app.services.reasoning.local_stub import classify_local


def test_chicken_original_friday_1904_ist_45min_window():
    # Seed sim time: 2026-09-18T13:34:00Z == Friday 2026-09-18 19:04 IST.
    at_utc = datetime(2026, 9, 18, 13, 34, 0, tzinfo=timezone.utc)
    predicted = expected_units_in_window(
        daily_volume=420,
        at_utc=at_utc,
        timezone_str="Asia/Kolkata",
        window_minutes=45,
        weather="clear",
    )
    # hand-computed: hour=19 -> weight 0.14; Friday -> dow_mult 1.25;
    # clear -> weather_mult 1.0
    # hourly_units = 420 * 0.14 * 1.25 * 1.0 = 73.5
    # predicted = 73.5 * (45/60) = 55.125 -> rounds to 55.1
    assert predicted == 55.1


def test_weather_modifier_applies():
    at_utc = datetime(2026, 9, 18, 13, 34, 0, tzinfo=timezone.utc)
    clear = expected_units_in_window(420, at_utc, "Asia/Kolkata", 45, "clear")
    rain = expected_units_in_window(420, at_utc, "Asia/Kolkata", 45, "rain")
    heatwave = expected_units_in_window(420, at_utc, "Asia/Kolkata", 45, "heatwave")
    assert rain == round(clear * 1.18, 1)
    assert heatwave == round(clear * 0.92, 1)


def test_unknown_hour_falls_back_to_default_weight():
    # 03:00 UTC == 08:30 IST -> not in BASE_HOURLY_WEIGHTS, default 0.02
    at_utc = datetime(2026, 9, 18, 3, 0, 0, tzinfo=timezone.utc)
    predicted = expected_units_in_window(420, at_utc, "Asia/Kolkata", 60, "clear")
    # hourly_units = 420 * 0.02 * 1.25 (Friday) = 10.5; * (60/60) = 10.5
    assert predicted == 10.5


def test_classify_local_runout_keywords():
    assert classify_local("Are we going to run out of corn cups?") == "RUNOUT_CHECK"
    assert classify_local("How's the chicken holding up?") == "RUNOUT_CHECK"


def test_classify_local_forecast_keywords():
    assert classify_local("What's the forecast for the next hour?") == "FORECAST_CHECK"
    assert classify_local("How much will we sell tonight?") == "FORECAST_CHECK"


def test_classify_local_general_status_default():
    assert classify_local("What's our current stock look like?") == "GENERAL_STATUS"
