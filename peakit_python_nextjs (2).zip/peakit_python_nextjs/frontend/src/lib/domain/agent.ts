/**
 * Reasoning layer — the TypeScript mirror of agent.py, used by the local
 * mock API routes (app/api/v1/agent/ask/route.ts).
 *
 * As in the original Python prototype, routeIntent() below is a stand-in
 * for a real LLM tool-use call. The Python (FastAPI) backend replaces this
 * exact function with a call to AiReasoningPort — implemented either by
 * LocalStubReasoningAdapter (the same keyword-matching logic as here, in
 * Java) or BedrockReasoningAdapter (a real Claude-on-Bedrock tool-use
 * call). See backend/.../service/AgentOrchestrationService.java.
 *
 * Nothing downstream of routeIntent() needs to know or care which one
 * produced the intent string — that's the whole point of the seam.
 */

import { MENU_ITEMS, WATCHED_RUNOUT_ITEMS } from "./menu";
import { StoreState } from "./storeState";
import {
  ToolCall,
  resetToolLog,
  getToolLog,
  requiredPrepForWindow,
  predictRunout,
  createRestockReminder,
  forecastDemand,
  getInventoryLevel,
} from "./tools";

export type Intent =
  | "runout_check"
  | "forecast_check"
  | "general_status";

export interface AgentResponse {
  query: string;
  intent: Intent;
  toolCalls: ToolCall[];
  recommendation: string;
}

/** The swap point. Production: Claude via AWS Bedrock's Converse API, with
 * the functions in tools.ts (or their Java/Spring equivalents) exposed as
 * its tool schema. */
export function routeIntent(query: string): Intent {
  const q = query.toLowerCase();
  if (q.includes("runout") || q.includes("run out") || q.includes("corn cup") || q.includes("chicken")) {
    return "runout_check";
  }
  if (q.includes("forecast") || q.includes("sell") || q.includes("demand")) {
    return "forecast_check";
  }
  return "general_status";
}

export function handleQuery(state: StoreState, query: string): AgentResponse {
  resetToolLog(state.storeId);
  const intent = routeIntent(query);

  switch (intent) {
    case "runout_check":
      return handleRunout(state, query);
    case "forecast_check":
      return handleForecast(state, query);
    default:
      return handleGeneral(state, query);
  }
}

function handleRunout(state: StoreState, query: string): AgentResponse {
  const lines: string[] = [];
  let worst: { itemId: string; eta: number } | null = null;

  for (const itemId of WATCHED_RUNOUT_ITEMS) {
    const prepCall = requiredPrepForWindow(state, itemId, 45);
    const runoutCall = predictRunout(state, itemId);
    const shortfall = prepCall.output.shortfallUnits as number;
    const eta = runoutCall.output.minutesToRunout as number;
    if (shortfall > 0) {
      const name = MENU_ITEMS[itemId].name;
      lines.push(`${name}: need ${Math.round(shortfall)} more in the next 45 min (runs out in ~${Math.round(eta)} min at current pace)`);
      if (!worst || eta < worst.eta) worst = { itemId, eta };
    }
  }

  let recommendation: string;
  if (worst) {
    createRestockReminder(state, worst.itemId, null);
    recommendation = "You'll need " + lines.join("; ") + ". Want me to fire a restock reminder?";
  } else {
    recommendation = "Inventory is tracking fine against the next 45 minutes of forecast demand — no action needed.";
  }

  return { query, intent: "runout_check", toolCalls: getToolLog(state.storeId), recommendation };
}

function handleForecast(state: StoreState, query: string): AgentResponse {
  const lines = Object.keys(MENU_ITEMS).map((itemId) => {
    const call = forecastDemand(state, itemId, 60);
    return `${MENU_ITEMS[itemId].name}: ~${Math.round(call.output.predictedUnits as number)} in the next hour`;
  });
  const recommendation = "Next-hour forecast — " + lines.join("; ") + ".";
  return { query, intent: "forecast_check", toolCalls: getToolLog(state.storeId), recommendation };
}

function handleGeneral(state: StoreState, query: string): AgentResponse {
  const lines = Object.keys(MENU_ITEMS).map((itemId) => {
    const call = getInventoryLevel(state, itemId);
    return `${MENU_ITEMS[itemId].name}: ${call.output.onHand} ${call.output.unit}`;
  });
  const recommendation = "Current stock — " + lines.join("; ");
  return { query, intent: "general_status", toolCalls: getToolLog(state.storeId), recommendation };
}
