import type { Metadata } from "next";
import "./globals.css";

// Deliberately NOT using next/font/google (Geist) here — this sandbox's
// network allowlist blocks fonts.googleapis.com/fonts.gstatic.com, which
// would break `next build`. System font stack instead; swap back to
// next/font/google once you're building somewhere with normal internet
// access, if you want it.

export const metadata: Metadata = {
  title: "PeaKit — AI Store Manager",
  description: "PeaKit watches your store in real time and tells the manager what to do, and when. An assistant, not a replacement.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">{children}</body>
    </html>
  );
}
