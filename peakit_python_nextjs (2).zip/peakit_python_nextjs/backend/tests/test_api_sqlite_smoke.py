"""Boot/endpoint smoke tests using a throwaway SQLite file in place of
Postgres.

IMPORTANT CAVEAT (documented in README too): this is NOT a substitute for
testing against real Postgres. It exists purely to verify the FastAPI app
boots, the OpenAPI schema generates, and the endpoint wiring / JSON field
names / business logic behave as expected, without needing a live Postgres
instance in this sandbox. `Double`, the BigInteger/Integer primary-key
variant, and `DateTime(timezone=True)` all behave slightly differently on
SQLite than on Postgres, but none of the differences affect the assertions
below (see app/models.py and app/services/time_utils.py for how those
dialect differences are neutralized).

Each test gets its own fresh SQLite file and its own FastAPI dependency
override for `get_db`, so tests don't share state and we never need to
reload any modules (which would re-trigger SQLAlchemy declarative class
registration errors).
"""
from __future__ import annotations

import os
import tempfile

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db import Base, get_db
from app.main import app
from app.seed import seed_demo_data

STORE_ID = "IN-BLR-0142"


@pytest.fixture()
def client():
    db_fd, db_path = tempfile.mkstemp(suffix=".db")
    os.close(db_fd)
    engine = create_engine(f"sqlite:///{db_path}", future=True)
    Base.metadata.create_all(bind=engine)
    TestSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    seed_db = TestSessionLocal()
    seed_demo_data(seed_db)
    seed_db.close()

    def override_get_db():
        db = TestSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as test_client:
        test_client.test_session_factory = TestSessionLocal  # for tests needing raw DB access
        yield test_client

    app.dependency_overrides.clear()
    engine.dispose()
    os.remove(db_path)


def test_openapi_schema_generates(client):
    resp = client.get("/openapi.json")
    assert resp.status_code == 200
    assert resp.json()["info"]["title"] == "PeaKit API"


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_store_state_seed_values(client):
    resp = client.get(f"/api/v1/stores/{STORE_ID}/state")
    assert resp.status_code == 200
    body = resp.json()
    assert body["storeId"] == STORE_ID
    assert body["storeName"] == "PeaKit Demo Kitchen — Koramangala"
    assert body["weather"] == "clear"
    assert body["simTime"] == "2026-09-18T13:34:00Z"
    assert body["inventory"] == {
        "chicken_original": 28.0,
        "corn_cup": 17.0,
        "fries_reg": 64.0,
        "beverage_cola": 210.0,
    }


def test_advance_decrements_on_hand(client):
    resp = client.post(f"/api/v1/stores/{STORE_ID}/advance", json={"minutes": 10})
    assert resp.status_code == 200
    body = resp.json()
    # chicken_original: 28 - 0.62*10 = 21.8
    assert body["inventory"]["chicken_original"] == 21.8
    assert body["simTime"] == "2026-09-18T13:44:00Z"


def test_reset_restores_seed_state(client):
    client.post(f"/api/v1/stores/{STORE_ID}/advance", json={"minutes": 500})
    resp = client.post(f"/api/v1/stores/{STORE_ID}/reset")
    body = resp.json()
    assert body["simTime"] == "2026-09-18T13:34:00Z"
    assert body["weather"] == "clear"
    assert body["inventory"]["chicken_original"] == 28.0


def test_forecast_tool_matches_hand_computed_value(client):
    resp = client.post("/api/v1/tools/forecast", json={"itemId": "chicken_original", "windowMinutes": 45})
    assert resp.status_code == 200
    body = resp.json()
    assert body == {"itemId": "chicken_original", "windowMinutes": 45, "predictedUnits": 55.1}


def test_inventory_tool(client):
    resp = client.post("/api/v1/tools/inventory", json={"itemId": "corn_cup"})
    assert resp.json() == {"itemId": "corn_cup", "onHand": 17.0, "unit": "cups"}


def test_runout_tool(client):
    resp = client.post("/api/v1/tools/runout", json={"itemId": "corn_cup"})
    body = resp.json()
    assert body["itemId"] == "corn_cup"
    assert body["onHand"] == 17.0
    assert body["sellThroughPerMin"] == 0.58
    # 17 / 0.58 = 29.310... -> 29.3
    assert body["minutesToRunout"] == 29.3


def test_runout_tool_zero_rate_returns_infinity_sentinel(client):
    # All seeded menu items have a positive sell-through rate, so to
    # exercise the `rate <= 0 -> "Infinity"` branch we insert one more menu
    # item + inventory row directly, bypassing the API.
    from app.models import InventoryLevel, MenuItem

    db = client.test_session_factory()
    db.add(
        MenuItem(
            item_id="zero_rate_item",
            name="Zero Rate Item",
            prep_minutes=1,
            par_level=10,
            unit="units",
            daily_volume=0,
            sell_through_per_min=0,
        )
    )
    db.add(InventoryLevel(store_id=STORE_ID, item_id="zero_rate_item", on_hand=5))
    db.commit()
    db.close()

    resp = client.post("/api/v1/tools/runout", json={"itemId": "zero_rate_item"})
    body = resp.json()
    assert body["minutesToRunout"] == "Infinity"


def test_required_prep_tool_and_audit_log_grouping(client):
    resp = client.post(
        "/api/v1/tools/required-prep", json={"itemId": "chicken_original", "windowMinutes": 45}
    )
    body = resp.json()
    assert body["predictedUnits"] == 55.1
    assert body["onHand"] == 28.0
    assert body["shortfallUnits"] == round(55.1 - 28.0, 1)

    audit_resp = client.get(f"/api/v1/stores/{STORE_ID}/audit-log?limit=50")
    tool_names = [row["toolName"] for row in audit_resp.json()]
    # Calling required-prep should have logged BOTH forecast_demand and
    # required_prep_for_window rows.
    assert "forecast_demand" in tool_names
    assert "required_prep_for_window" in tool_names


def test_restock_reminder_tool(client):
    resp = client.post(
        "/api/v1/tools/restock-reminder", json={"itemId": "corn_cup", "quantityHint": 20}
    )
    assert resp.json() == {"itemId": "corn_cup", "quantityHint": 20.0, "status": "reminder_created"}


def test_agent_ask_runout_check(client):
    resp = client.post(
        "/api/v1/agent/ask", json={"storeId": STORE_ID, "query": "Are we going to run out of corn cups?"}
    )
    body = resp.json()
    assert body["intent"] == "runout_check"
    assert len(body["toolCalls"]) > 0


def test_agent_ask_forecast_check(client):
    resp = client.post(
        "/api/v1/agent/ask", json={"storeId": STORE_ID, "query": "What's the demand forecast?"}
    )
    body = resp.json()
    assert body["intent"] == "forecast_check"
    assert "Next-hour forecast" in body["recommendation"]


def test_agent_ask_general_status(client):
    resp = client.post(
        "/api/v1/agent/ask", json={"storeId": STORE_ID, "query": "How's everything looking?"}
    )
    body = resp.json()
    assert body["intent"] == "general_status"
    assert "Current stock" in body["recommendation"]
