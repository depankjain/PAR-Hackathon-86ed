"""The five PeaKit tools, each backed by the demand-forecast formula and/or
the inventory table, and each recording a row in the tool-call audit log.

Every function accepts an explicit `request_id` so that multiple tool calls
triggered by a single `/agent/ask` request can be grouped together in the
audit log, exactly like the Java reference implementation.
"""
from __future__ import annotations

import uuid
from typing import Any

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import InventoryLevel, MenuItem, Store
from app.services import demand_forecast
from app.services.audit_log import record_tool_call


def new_request_id() -> str:
    return uuid.uuid4().hex


def _get_store(db: Session, store_id: str) -> Store:
    store = db.get(Store, store_id)
    if store is None:
        raise HTTPException(status_code=404, detail=f"Unknown store '{store_id}'")
    return store


def _get_menu_item(db: Session, item_id: str) -> MenuItem:
    item = db.get(MenuItem, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail=f"Unknown item '{item_id}'")
    return item


def _get_inventory_row(db: Session, store_id: str, item_id: str) -> InventoryLevel:
    stmt = select(InventoryLevel).where(
        InventoryLevel.store_id == store_id, InventoryLevel.item_id == item_id
    )
    row = db.execute(stmt).scalar_one_or_none()
    if row is None:
        raise HTTPException(
            status_code=404, detail=f"No inventory row for store '{store_id}' item '{item_id}'"
        )
    return row


def get_inventory_level(
    db: Session, *, store_id: str, item_id: str, request_id: str | None = None
) -> dict[str, Any]:
    item = _get_menu_item(db, item_id)
    inv = _get_inventory_row(db, store_id, item_id)

    output = {"itemId": item_id, "onHand": inv.on_hand, "unit": item.unit}
    record_tool_call(
        db,
        store_id=store_id,
        tool_name="get_inventory_level",
        source_system="PAR OPS — Inventory",
        inputs={"itemId": item_id},
        output=output,
        request_id=request_id or new_request_id(),
    )
    return output


def predict_runout(
    db: Session, *, store_id: str, item_id: str, request_id: str | None = None
) -> dict[str, Any]:
    item = _get_menu_item(db, item_id)
    inv = _get_inventory_row(db, store_id, item_id)

    rate = item.sell_through_per_min
    if rate > 0:
        minutes_to_runout: Any = round(inv.on_hand / rate, 1)
    else:
        minutes_to_runout = "Infinity"

    output = {
        "itemId": item_id,
        "onHand": inv.on_hand,
        "sellThroughPerMin": rate,
        "minutesToRunout": minutes_to_runout,
    }
    record_tool_call(
        db,
        store_id=store_id,
        tool_name="predict_runout",
        source_system="PAR OPS Inventory + PAR POS sell-through",
        inputs={"itemId": item_id},
        output=output,
        request_id=request_id or new_request_id(),
    )
    return output


def forecast_demand(
    db: Session,
    *,
    store_id: str,
    item_id: str,
    window_minutes: int,
    request_id: str | None = None,
) -> dict[str, Any]:
    store = _get_store(db, store_id)
    item = _get_menu_item(db, item_id)

    at_utc = store.sim_time_override
    predicted_units = demand_forecast.expected_units_in_window(
        daily_volume=item.daily_volume,
        at_utc=at_utc,
        timezone_str=store.timezone,
        window_minutes=window_minutes,
        weather=store.weather,
    )

    output = {"itemId": item_id, "windowMinutes": window_minutes, "predictedUnits": predicted_units}
    record_tool_call(
        db,
        store_id=store_id,
        tool_name="forecast_demand",
        source_system="PAR OPS — Forecasting",
        inputs={"itemId": item_id, "windowMinutes": window_minutes},
        output=output,
        request_id=request_id or new_request_id(),
    )
    return output


def required_prep_for_window(
    db: Session,
    *,
    store_id: str,
    item_id: str,
    window_minutes: int,
    request_id: str | None = None,
) -> dict[str, Any]:
    # Shared request_id so both the inner forecast_demand row and this row
    # group together under the same request, matching the Java behaviour of
    # calling the forecast tool's logic inline.
    shared_request_id = request_id or new_request_id()

    forecast = forecast_demand(
        db,
        store_id=store_id,
        item_id=item_id,
        window_minutes=window_minutes,
        request_id=shared_request_id,
    )
    inv = _get_inventory_row(db, store_id, item_id)

    predicted_units = forecast["predictedUnits"]
    shortfall_units = max(0.0, round(predicted_units - inv.on_hand, 1))

    output = {
        "itemId": item_id,
        "windowMinutes": window_minutes,
        "predictedUnits": predicted_units,
        "onHand": inv.on_hand,
        "shortfallUnits": shortfall_units,
    }
    record_tool_call(
        db,
        store_id=store_id,
        tool_name="required_prep_for_window",
        source_system="PAR OPS Forecasting + Inventory",
        inputs={"itemId": item_id, "windowMinutes": window_minutes},
        output=output,
        request_id=shared_request_id,
    )
    return output


def create_restock_reminder(
    db: Session,
    *,
    store_id: str,
    item_id: str,
    quantity_hint: float | None,
    request_id: str | None = None,
) -> dict[str, Any]:
    output = {"itemId": item_id, "quantityHint": quantity_hint, "status": "reminder_created"}
    record_tool_call(
        db,
        store_id=store_id,
        tool_name="create_restock_reminder",
        source_system="PAR OPS — Task Queue / KDS",
        inputs={"itemId": item_id, "quantityHint": quantity_hint},
        output=output,
        request_id=request_id or new_request_id(),
    )
    return output
