"""Local, no-AWS-required keyword classifier. This is the default provider
(`PEAKIT_AI_PROVIDER=local`) and also the fallback target if the Bedrock
adapter throws for any reason."""
from __future__ import annotations

from app.services.reasoning.base import FORECAST_CHECK, GENERAL_STATUS, RUNOUT_CHECK


class LocalStubReasoning:
    def classify_intent(self, query: str) -> str:
        return classify_local(query)


def classify_local(query: str) -> str:
    q = query.lower()
    if "runout" in q or "run out" in q or "corn cup" in q or "chicken" in q:
        return RUNOUT_CHECK
    if "forecast" in q or "sell" in q or "demand" in q:
        return FORECAST_CHECK
    return GENERAL_STATUS
