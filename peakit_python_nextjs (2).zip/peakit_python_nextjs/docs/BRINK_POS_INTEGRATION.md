# Integrating PeaKit with PAR Brink POS

This document explains what PAR Brink POS actually is, exactly what data it can give PeaKit, and the concrete engineering steps to wire it into the existing PeaKit codebase (`peakit_python_nextjs/backend`) in place of the seeded/synthetic sell-through data used today. It's written for whoever picks up the "connect this to a real store" work next.

**Honesty up front:** this document is grounded in PAR's public developer-portal documentation and press material (cited at the bottom), not in a live integration test — no Brink API credentials or sandbox access were available while building this. Anywhere a real API's exact request/response shape matters, that's flagged as "confirm with PAR" rather than guessed at.

---

## 1. What PAR Brink POS is, and what it isn't

Brink POS is PAR's point-of-sale system — the software actually running the register/kitchen-display terminals in a restaurant, recording every order and payment as it happens. It is **not** the same system as PAR OPS / Data Central, which is where inventory counts, purchasing, and back-office operations data live. This distinction matters a lot for PeaKit specifically:

| PeaKit needs... | ...which really lives in |
|---|---|
| How fast an item is *selling right now* (`sellThroughPerMin`) | **Brink POS** — derived from real order/transaction data |
| How much of an item is *currently on hand* (`onHand`) | **PAR OPS / Data Central** — inventory counts, not Brink |
| Menu item names, units, prep times (mostly static reference data) | Either — Brink has a menu/items API too; OPS is usually the system of record |

So a full "real data" rollout of PeaKit needs **two** integrations, not one — this document only covers the Brink half (what was asked for here). The OPS/Data Central half is a separate, similarly-shaped piece of work, noted again in §6.

## 2. The actual API surface

PAR's current, unified developer portal is **`developers.partech.com`** (specifically `developers.partech.com/docs/parpos-cloud-apis`). This superseded an older, still-live portal at `brinkapiportal.parpos.com` (formerly `brinkapiportal.brinkpos.net`) — expect to land on the newer one, but don't be surprised if older links redirect there.

The core Brink API is **SOAP, not REST**: each service is described by a WSDL file, and most tooling generates a typed client class from that WSDL rather than hand-writing HTTP calls. The services relevant to PeaKit:

- **`Sales2.svc`** — sales/order data. Confirmed methods include `GetOrders` (the one PeaKit actually needs — order-level detail, which is what real sell-through rate has to be computed from), `GetCurrentBusinessDate`, and `GetDeposits`.
- **`Settings.svc` / `Settings2.svc`** — configuration/reference data, including item/menu master data (`GetItems`-style calls) — this is the natural source for item IDs, names, and units, potentially replacing PeaKit's hardcoded `MENU_ITEMS` seed list.
- **`Kitchen.svc`**, **`Labor2.svc`**, **`HouseAccounts.svc`** exist too, but aren't relevant to PeaKit's three capabilities (no staffing/labor features, per this project's explicit scope).

**Authentication:** every call requires an `AccessToken` and a `LocationToken`, sent in the HTTP request headers (the exact header names and whether some calls expect them in the body instead should be confirmed against the current WSDL/portal docs, since this varies by service). `LocationToken` scopes a call to one specific restaurant location — practically, this means PeaKit's Brink integration is inherently **per-store**: each store PeaKit is piloted at needs its own token, obtained through PAR.

**Getting access:** there's no self-serve signup visible in the portal search results — the documented path is contacting `api.support@partech.com` to request API access/credentials for a given account and location. This should be one of the very first steps in any real pilot, since it has a lead time outside engineering's control.

There's a **separate, different** API worth not confusing this with: the **PAR Ordering API** (`developers.partech.com/docs/ordering-api`) is REST/JSON, and it's for the opposite direction — online-ordering partners (the kind of integration PAR has done with Bite, Goji, Open Dining) *pushing new orders into* Brink. PeaKit doesn't need to create orders; it needs to *read* sales history, so `Sales2`/`GetOrders` is the relevant surface, not the Ordering API.

## 3. What "confirm with PAR" actually means here

The searches behind this document confirmed *that* `Sales2.GetOrders` exists and *that* token-based auth is used, but not the exact request/response schema (date-range parameters, pagination, whether item-level line detail is included per order or requires a second call, response payload size limits, and whether there's a webhook/push option or this is poll-only). Before writing real integration code against this, get:

1. Actual WSDL files for `Sales2.svc` and `Settings.svc` (from the developer portal, once credentials are issued).
2. A **sandbox/test location** if PAR offers one — do not build the first version of this against a live production store's real terminal.
3. A confirmed answer on **polling vs. push**: nothing found during research confirms Brink offers webhooks for new orders. If it doesn't, PeaKit's integration will need to poll `GetOrders` on a schedule (see §5) rather than receive events.

## 4. Where this plugs into PeaKit's existing architecture

Recall from `docs/CODE_WALKTHROUGH.md` §2.10–2.11: `sell_through_per_min` is currently a **static, seeded number** per menu item (`app/seed.py`'s `MENU_ITEMS` list — e.g. `chicken_original` is hardcoded at `0.62`). Every other calculation in the system (`predict_runout`, `demand_forecast.expected_units_in_window`'s hourly-weight table) either uses this number directly or was itself hand-tuned around this same synthetic scenario. A real Brink integration's job is to make that one number (and, longer-term, the whole demand-forecast model) reflect *actual* recent sales instead of a fixed guess — without changing the shape of anything downstream, exactly the same "swap the seam, not the architecture" principle already used for the AI reasoning port (`local_stub.py` vs `bedrock_adapter.py`).

## 5. Concrete implementation plan

### 5.1 New module: a Brink client, isolated behind its own seam

Add `app/integrations/brink_client.py`:

```python
# app/integrations/brink_client.py
"""Thin client for PAR Brink POS's Sales2 SOAP service. Isolated here so
nothing else in the codebase needs to know Brink is SOAP-based, or needs to
change if/when PAR migrates this to a newer REST API."""

from datetime import date
from typing import Any

class BrinkClient:
    def __init__(self, base_url: str, access_token: str, location_token: str):
        self._base_url = base_url
        self._access_token = access_token
        self._location_token = location_token
        self._soap_client = None  # lazily built - see note below

    def _client(self):
        if self._soap_client is None:
            # zeep is the standard modern Python SOAP client; it builds a
            # callable client directly from a WSDL URL.
            import zeep
            self._soap_client = zeep.Client(wsdl=f"{self._base_url}/Sales2.svc?singleWsdl")
        return self._soap_client

    def get_orders(self, business_date: date) -> list[dict[str, Any]]:
        """Returns raw order records for one business date. Exact response
        shape TBD against the real WSDL - confirm field names before
        trusting this method signature."""
        client = self._client()
        headers = {"AccessToken": self._access_token, "LocationToken": self._location_token}
        # placeholder call shape - replace once the real WSDL is available
        return client.service.GetOrders(businessDate=business_date, _soapheaders=headers)
```

`zeep` is the standard, actively-maintained Python SOAP client library (add it to `requirements.txt`); it can build a callable client directly from a WSDL URL, which is the natural fit for a WSDL-described API like this one. Everything Brink-specific — the SOAP plumbing, the token headers, the WSDL URL — is isolated in this one file. Nothing in `tools_service.py` or `orchestration.py` should ever import `zeep` directly.

### 5.2 A sync job that turns raw orders into `sell_through_per_min`

Add `app/services/brink_sync.py`:

```python
# app/services/brink_sync.py
"""Periodically pulls recent Brink orders and recomputes each menu item's
sell_through_per_min from real sales, replacing the static seed value."""

import logging
from datetime import date, timedelta

from sqlalchemy.orm import Session

from app.integrations.brink_client import BrinkClient
from app.models import MenuItem

logger = logging.getLogger("peakit.brink_sync")

def sync_sell_through_rates(db: Session, brink: BrinkClient, lookback_days: int = 1) -> None:
    """Recomputes sell_through_per_min for every menu item from the last
    `lookback_days` of real Brink orders. Falls back to leaving the
    existing (seeded or previously-synced) value untouched on any error -
    a Brink outage must never take PeaKit's numbers to zero, mirroring the
    Bedrock-outage-safe-fallback pattern used for AI reasoning."""
    try:
        orders = brink.get_orders(business_date=date.today() - timedelta(days=lookback_days))
    except Exception as exc:  # noqa: BLE001 - deliberately broad, see docstring
        logger.warning("Brink sync failed (%s); keeping existing sell-through rates", exc)
        return

    units_sold: dict[str, float] = {}
    for order in orders:
        for line in order.get("lineItems", []):  # exact key names TBD - confirm against real payload
            item_id = line["itemId"]
            units_sold[item_id] = units_sold.get(item_id, 0) + line["quantity"]

    minutes_covered = lookback_days * 24 * 60
    for item_id, units in units_sold.items():
        item = db.get(MenuItem, item_id)
        if item is not None:
            item.sell_through_per_min = round(units / minutes_covered, 4)
    db.commit()
```

This function is deliberately written so a Brink outage or an unexpected response shape **degrades gracefully** — it logs and returns, leaving whatever rate was already in the database, rather than raising an exception that would break every tool call depending on `sell_through_per_min` for the rest of the day. This is the same safety principle already applied to the AI reasoning seam (`bedrock_adapter.py`'s catch-anything-and-fall-back behavior) — real integrations with an external system should follow the same rule everywhere.

Run this on a schedule — the simplest option for a pilot is an APScheduler job or an OS-level cron hitting a small internal endpoint (`POST /internal/sync-brink`) every 15–30 minutes; a more production-shaped option later is an AWS EventBridge rule invoking a small Lambda or ECS scheduled task, consistent with the AWS deployment already sketched in `infra/`.

### 5.3 Configuration

Add to `app/config.py`'s `Settings`:

```python
brink_enabled: bool = False
brink_base_url: str = ""
brink_access_token: str = ""
brink_location_token: str = ""
```

`brink_enabled` defaults to `False` so nothing changes for anyone running this locally without Brink credentials — exactly the same opt-in pattern `peakit_ai_provider` already uses for Bedrock. Real tokens belong in a secrets manager (AWS Secrets Manager, matching `infra/lib/peakit-infra-stack.ts`'s existing `DB_PASSWORD` handling) in any deployed environment, never committed to source or a plain `.env` file in git.

### 5.4 Wiring it up

In `app/main.py`'s startup hook, alongside `init_db_and_seed()`:

```python
@app.on_event("startup")
def on_startup() -> None:
    init_db_and_seed()
    if settings.brink_enabled:
        # schedule sync_sell_through_rates() to run periodically here
        ...
```

No other file needs to change. `tools_service.py`'s `predict_runout` and `demand_forecast.py`'s formula already read `sell_through_per_min` from the `MenuItem` row — they have no idea whether that number came from a hardcoded seed or a real Brink sync, which is exactly the point.

## 6. What this doesn't cover (and shouldn't be skipped)

- **On-hand inventory** (`InventoryLevel.on_hand`) still needs a *separate* integration against PAR OPS / Data Central — Brink alone cannot tell you what's physically left in the walk-in. Without that second integration, `predict_runout` will have a real sell-through rate but a fake stock level, which is only half the fix.
- **Menu item master data** (`MenuItem.name`, `.unit`, `.par_level`, `.prep_minutes`) could plausibly come from Brink's `Settings`/`GetItems`-style calls too, but `par_level` and `prep_minutes` in particular are more likely to be operationally owned in OPS/Data Central or set directly by store management — confirm ownership before wiring a sync for those fields specifically.
- **A real pilot needs exactly one store's real credentials first.** Get one location's `LocationToken` working end-to-end (even just logging real vs. seeded rates side-by-side, not yet trusted for live recommendations) before expanding to more stores — this mirrors the phased rollout already sketched in the project's business-case slide ("confirm access, wire backend to real data at 1–2 stores, run a pilot").

---

## Sources

- [PAR POS™ Documentation & Release Notes](https://cdn.parpos.com/Documentation.html)
- [Sales2.svc — PAR POS](https://brinkapiportal.parpos.com/sales2)
- [Best Practice & FAQs — PAR POS](https://brinkapiportal.parpos.com/bestpracticeandfaqs)
- [API Basics — PAR POS (Ordering API)](https://developers.partech.com/docs/ordering-api/api-basics)
- [Introduction — PAR POS (Ordering API)](https://developers.partech.com/docs/ordering-api)
- [PAR POS — Contact Us](https://brinkapiportal.parpos.com/contactus)
- [PAR Technology Announces New API Integration with Bite and Brink POS® Software — Nasdaq](https://www.nasdaq.com/press-release/par-technology-announces-new-api-integration-with-bite-and-brink-posr-software-2020)
