import { NextRequest, NextResponse } from "next/server";
import { getToolLog } from "@/lib/domain/tools";

// GET /api/v1/stores/{storeId}/audit-log?limit=50
// Mock: returns the in-memory per-store tool-call log. The real backend
// persists every ToolCall row to Postgres (see V1__init.sql's
// tool_call_audit_log table) so this survives restarts and is queryable
// for compliance review, per architecture doc section 6.
export async function GET(req: NextRequest, { params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  const limit = Number(req.nextUrl.searchParams.get("limit") ?? "50");
  const log = getToolLog(storeId).slice(-limit);
  return NextResponse.json(log);
}
