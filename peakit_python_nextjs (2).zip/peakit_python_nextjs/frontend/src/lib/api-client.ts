/**
 * Typed REST client. Every function here implements one path from
 * api-contract/openapi.yaml.
 *
 * NEXT_PUBLIC_API_BASE_URL controls where these calls go:
 *   - unset / "" (default)  -> same-origin /api/v1/... -> this app's own
 *     mock route handlers (src/app/api/v1/**), backed by the in-memory
 *     TypeScript domain model in src/lib/domain/.
 *   - "http://localhost:8000" -> the real Python (FastAPI) backend, once you've
 *     started it locally (see backend/README.md).
 *   - your deployed backend's URL once it's running on AWS behind the
 *     CDK-provisioned load balancer.
 *
 * No code in components/ ever needs to change when you flip this — that's
 * the entire point of building both sides to the same contract.
 */

import { StoreStateDto, AgentAskResponseDto, ToolCallDto } from "./types";

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    cache: "no-store",
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`PeaKit API error ${res.status} on ${path}: ${text}`);
  }
  return res.json() as Promise<T>;
}

export function getStoreState(storeId: string): Promise<StoreStateDto> {
  return apiFetch(`/api/v1/stores/${storeId}/state`);
}

export function advanceStoreClock(storeId: string, minutes: number): Promise<StoreStateDto> {
  return apiFetch(`/api/v1/stores/${storeId}/advance`, {
    method: "POST",
    body: JSON.stringify({ minutes }),
  });
}

export function resetStore(storeId: string): Promise<StoreStateDto> {
  return apiFetch(`/api/v1/stores/${storeId}/reset`, { method: "POST" });
}

export function getAuditLog(storeId: string, limit = 50): Promise<ToolCallDto[]> {
  return apiFetch(`/api/v1/stores/${storeId}/audit-log?limit=${limit}`);
}

export function askAgent(storeId: string, query: string): Promise<AgentAskResponseDto> {
  return apiFetch(`/api/v1/agent/ask`, {
    method: "POST",
    body: JSON.stringify({ storeId, query }),
  });
}
