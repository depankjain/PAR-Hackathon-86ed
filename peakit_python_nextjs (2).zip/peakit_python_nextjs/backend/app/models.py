"""SQLAlchemy ORM models mirroring the Java reference schema (V1__init.sql)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    DateTime,
    Double,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base

# BigInteger primary keys work as BIGSERIAL-equivalents on Postgres, but
# SQLite's autoincrement rowid aliasing only kicks in for a bare INTEGER
# primary key - so we swap in Integer for the sqlite dialect specifically.
# This only matters for this project's sqlite-based smoke tests; Postgres
# always sees BigInteger.
_ID_TYPE = BigInteger().with_variant(Integer, "sqlite")


class Store(Base):
    __tablename__ = "stores"

    store_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), nullable=False)
    weather: Mapped[str] = mapped_column(String(16), nullable=False, default="clear")
    sim_time_override: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class MenuItem(Base):
    __tablename__ = "menu_items"

    item_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    prep_minutes: Mapped[int] = mapped_column(Integer, nullable=False)
    par_level: Mapped[float] = mapped_column(Double, nullable=False)
    unit: Mapped[str] = mapped_column(String(32), nullable=False)
    daily_volume: Mapped[float] = mapped_column(Double, nullable=False)
    sell_through_per_min: Mapped[float] = mapped_column(Double, nullable=False)


class InventoryLevel(Base):
    __tablename__ = "inventory_levels"
    __table_args__ = (UniqueConstraint("store_id", "item_id", name="uq_inventory_store_item"),)

    id: Mapped[int] = mapped_column(_ID_TYPE, primary_key=True, autoincrement=True)
    store_id: Mapped[str] = mapped_column(String(32), ForeignKey("stores.store_id"), nullable=False)
    item_id: Mapped[str] = mapped_column(String(64), ForeignKey("menu_items.item_id"), nullable=False)
    on_hand: Mapped[float] = mapped_column(Double, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )


class ToolCallAuditLog(Base):
    __tablename__ = "tool_call_audit_log"

    id: Mapped[int] = mapped_column(_ID_TYPE, primary_key=True, autoincrement=True)
    store_id: Mapped[str] = mapped_column(String(32), ForeignKey("stores.store_id"), nullable=False)
    tool_name: Mapped[str] = mapped_column(String(64), nullable=False)
    source_system: Mapped[str] = mapped_column(String(128), nullable=False)
    inputs_json: Mapped[str] = mapped_column(Text, nullable=False)
    output_json: Mapped[str] = mapped_column(Text, nullable=False)
    called_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )
    request_id: Mapped[str] = mapped_column(String(64), nullable=False)
