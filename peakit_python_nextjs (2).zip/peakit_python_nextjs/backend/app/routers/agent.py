"""POST /api/v1/agent/ask - the orchestration endpoint."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import schemas
from app.db import get_db
from app.services import orchestration

router = APIRouter(prefix="/api/v1/agent", tags=["agent"])


@router.post("/ask", response_model=schemas.AgentAskResponse)
def ask(body: schemas.AgentAskRequest, db: Session = Depends(get_db)) -> dict:
    return orchestration.ask(db, store_id=body.store_id, query=body.query)
