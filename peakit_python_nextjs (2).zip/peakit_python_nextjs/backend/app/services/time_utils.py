"""Shared datetime -> wire-format helper.

All simulated timestamps in this system are conceptually UTC. Postgres's
TIMESTAMPTZ always hands SQLAlchemy back timezone-aware datetimes, but
SQLite (used only for this project's offline smoke tests) hands back naive
ones. This helper normalizes either case to the same
`"2026-09-18T13:34:00Z"` wire format.
"""
from __future__ import annotations

from datetime import datetime, timezone


def to_iso_utc_z(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
