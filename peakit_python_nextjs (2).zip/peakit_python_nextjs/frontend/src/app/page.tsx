"use client";

import { useCallback, useEffect, useState } from "react";
import Header from "@/components/Header";
import Dashboard from "@/components/Dashboard";
import ChatPanel from "@/components/ChatPanel";
import { STORE } from "@/lib/domain/menu";
import { getStoreState, advanceStoreClock, resetStore, askAgent } from "@/lib/api-client";
import { StoreStateDto } from "@/lib/types";

function formatClock(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString("en-US", { weekday: "short", hour: "numeric", minute: "2-digit" });
}

export default function Home() {
  const [state, setState] = useState<StoreStateDto | null>(null);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setState(await getStoreState(STORE.storeId));
  }, []);

  useEffect(() => {
    // Standard "fetch on mount" pattern — refresh() awaits the network call
    // before calling setState, so this doesn't cause the synchronous
    // cascading-render react-hooks warns about; the rule can't see that
    // through the indirection, hence the explicit disable.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    refresh();
  }, [refresh]);

  async function handleAdvance() {
    setLoading(true);
    try {
      setState(await advanceStoreClock(STORE.storeId, 15));
    } finally {
      setLoading(false);
    }
  }

  async function handleReset() {
    setLoading(true);
    try {
      setState(await resetStore(STORE.storeId));
    } finally {
      setLoading(false);
    }
  }

  async function handleAsk(query: string) {
    const response = await askAgent(STORE.storeId, query);
    // Re-pull dashboard state after every question, since a runout
    // question may have fired a restock reminder or the clock may have
    // moved — keeps the dashboard and the chat trail honest with each other.
    refresh();
    return response;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header clockLabel={state ? formatClock(state.simTime) : "…"} />
      <main className="mx-auto max-w-6xl px-6 py-8 grid grid-cols-1 lg:grid-cols-[1fr_1.1fr] gap-6">
        <Dashboard state={state} onAdvance={handleAdvance} onReset={handleReset} loading={loading} />
        <ChatPanel onAsk={handleAsk} />
      </main>
      <footer className="text-center text-xs text-slate-400 pb-8">
        PeaKit — running in local mock mode against synthetic data. No live PAR systems connected.
      </footer>
    </div>
  );
}
