"""GET/POST endpoints for simulated store state: state, advance, reset, and
the tool-call audit log."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app import schemas
from app.db import get_db
from app.seed import reset_demo_data
from app.services import store_state
from app.services.audit_log import fetch_recent, to_wire

router = APIRouter(prefix="/api/v1/stores", tags=["stores"])


@router.get("/{store_id}/state", response_model=schemas.StoreState)
def get_state(store_id: str, db: Session = Depends(get_db)) -> dict:
    return store_state.build_state(db, store_id)


@router.post("/{store_id}/advance", response_model=schemas.StoreState)
def advance(store_id: str, body: schemas.AdvanceRequest, db: Session = Depends(get_db)) -> dict:
    return store_state.advance(db, store_id, body.minutes)


@router.post("/{store_id}/reset", response_model=schemas.StoreState)
def reset(store_id: str, db: Session = Depends(get_db)) -> dict:
    # This is a single-store hackathon demo: reset always restores the one
    # seeded demo store (IN-BLR-0142) regardless of the path param, matching
    # the Java reference implementation's behaviour.
    reset_demo_data(db)
    return store_state.build_state(db, store_id)


@router.get("/{store_id}/audit-log", response_model=list[schemas.ToolCall])
def audit_log(
    store_id: str, limit: int = Query(default=50, ge=1, le=500), db: Session = Depends(get_db)
) -> list[dict]:
    rows = fetch_recent(db, store_id=store_id, limit=limit)
    return [to_wire(row) for row in rows]
