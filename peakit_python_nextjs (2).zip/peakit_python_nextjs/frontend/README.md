# PeaKit — Frontend (Next.js)

The manager-facing UI: a live store dashboard + a chat interface for asking
PeaKit questions. Talks to a REST backend over the contract defined in
`../api-contract/openapi.yaml`.

## Run it

```
npm install
npm run dev
```

Open http://localhost:3000. No other setup needed — by default this runs
in **mock mode**: `NEXT_PUBLIC_API_BASE_URL` is unset, so every API call
goes to this app's own route handlers under `src/app/api/v1/**`, which are
backed by an in-memory TypeScript port of the same domain logic used
elsewhere in this project (`src/lib/domain/`).

Verified in this repo: `npm run build` (production build, typechecked),
`npm run lint` (ESLint, zero warnings), and a live smoke test of every
route (see `docs/ARCHITECTURE.md` in the project root for the transcript).

## Pointing at the real backend

Copy `.env.local.example` to `.env.local` and set:

```
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
```

...to hit the Python/FastAPI backend in `../backend` once you have it
running (`docker compose up -d && uvicorn app.main:app --reload`, see
`../backend/README.md`). No frontend code changes needed either way — see
`src/lib/api-client.ts`.

## Project layout

```
src/
  app/
    page.tsx                  the dashboard + chat page
    layout.tsx                PeaKit branding, metadata
    api/v1/**/route.ts        local mock implementation of the shared contract
  components/
    Header.tsx                brand header + live clock
    Dashboard.tsx              inventory stock cards
    ChatPanel.tsx              chat UI + tool-call audit trail viewer
  lib/
    api-client.ts              typed fetch wrapper — the ONLY place that knows the base URL
    types.ts                   DTOs mirroring the OpenAPI contract
    domain/                    the mock backend's actual logic (menu, demand
                                formula, live state, tools, agent routing) —
                                a TypeScript port of the same design used in
                                the Python (FastAPI) backend and the original
                                Python prototype
```

## Why a "mock mode" instead of just calling the Python backend directly

This sandbox can't run a real Postgres instance for the FastAPI backend
(see `../backend/README.md`), so the frontend needed to be genuinely
clickable on its own. Mock mode isn't a toy — it implements the exact same
REST contract (`../api-contract/openapi.yaml`) the real backend
implements, using the same tool-calling/audit-trail design. Swapping to
the real backend later is the one-line env var change above, not a
rewrite.
