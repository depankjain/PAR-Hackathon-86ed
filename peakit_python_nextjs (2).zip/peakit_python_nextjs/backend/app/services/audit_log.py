"""Persistence helper for the tool-call audit log."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ToolCallAuditLog
from app.services.time_utils import to_iso_utc_z


def record_tool_call(
    db: Session,
    *,
    store_id: str,
    tool_name: str,
    source_system: str,
    inputs: dict[str, Any],
    output: dict[str, Any],
    request_id: str,
) -> ToolCallAuditLog:
    row = ToolCallAuditLog(
        store_id=store_id,
        tool_name=tool_name,
        source_system=source_system,
        inputs_json=json.dumps(inputs),
        output_json=json.dumps(output),
        called_at=datetime.now(timezone.utc),
        request_id=request_id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def fetch_recent(db: Session, *, store_id: str, limit: int = 50) -> list[ToolCallAuditLog]:
    stmt = (
        select(ToolCallAuditLog)
        .where(ToolCallAuditLog.store_id == store_id)
        .order_by(ToolCallAuditLog.called_at.desc(), ToolCallAuditLog.id.desc())
        .limit(limit)
    )
    return list(db.execute(stmt).scalars().all())


def to_wire(row: ToolCallAuditLog) -> dict[str, Any]:
    return {
        "toolName": row.tool_name,
        "sourceSystem": row.source_system,
        "inputs": json.loads(row.inputs_json),
        "output": json.loads(row.output_json),
        "calledAt": to_iso_utc_z(row.called_at),
    }
