"""The 5 individual PeaKit tools.

Design choice: this is a single-store hackathon demo, so `storeId` is an
optional query parameter on every tool endpoint here, defaulting to the one
demo store (IN-BLR-0142 / `settings.default_store_id`) rather than being a
required field on every request body. This keeps the request bodies
identical to the shared OpenAPI contract's `ForecastRequest` / `ItemRequest`
/ `RestockReminderRequest` shapes while still letting the audit log and
inventory lookups know which store they're operating on.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app import schemas
from app.config import get_settings
from app.db import get_db
from app.services import tools_service

router = APIRouter(prefix="/api/v1/tools", tags=["tools"])

settings = get_settings()


def _store_id_param(
    store_id: str = Query(default=settings.default_store_id, alias="storeId")
) -> str:
    return store_id


@router.post("/forecast", response_model=schemas.ForecastResponse)
def forecast(
    body: schemas.ForecastRequest,
    store_id: str = Depends(_store_id_param),
    db: Session = Depends(get_db),
) -> dict:
    return tools_service.forecast_demand(
        db, store_id=store_id, item_id=body.item_id, window_minutes=body.window_minutes
    )


@router.post("/inventory", response_model=schemas.InventoryResponse)
def inventory(
    body: schemas.ItemRequest,
    store_id: str = Depends(_store_id_param),
    db: Session = Depends(get_db),
) -> dict:
    return tools_service.get_inventory_level(db, store_id=store_id, item_id=body.item_id)


@router.post("/runout", response_model=schemas.RunoutResponse)
def runout(
    body: schemas.ItemRequest,
    store_id: str = Depends(_store_id_param),
    db: Session = Depends(get_db),
) -> dict:
    return tools_service.predict_runout(db, store_id=store_id, item_id=body.item_id)


@router.post("/required-prep", response_model=schemas.RequiredPrepResponse)
def required_prep(
    body: schemas.ForecastRequest,
    store_id: str = Depends(_store_id_param),
    db: Session = Depends(get_db),
) -> dict:
    return tools_service.required_prep_for_window(
        db, store_id=store_id, item_id=body.item_id, window_minutes=body.window_minutes
    )


@router.post("/restock-reminder", response_model=schemas.RestockReminderResponse)
def restock_reminder(
    body: schemas.RestockReminderRequest,
    store_id: str = Depends(_store_id_param),
    db: Session = Depends(get_db),
) -> dict:
    return tools_service.create_restock_reminder(
        db, store_id=store_id, item_id=body.item_id, quantity_hint=body.quantity_hint
    )
