import { STORE } from "@/lib/domain/menu";

export default function Header({ clockLabel }: { clockLabel: string }) {
  return (
    <header className="border-b border-slate-200 bg-white/80 backdrop-blur sticky top-0 z-10">
      <div className="mx-auto max-w-6xl px-6 py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
            P
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">PeaKit</h1>
              <span className="text-xs font-semibold uppercase tracking-wide text-indigo-500">AI Store Manager</span>
            </div>
            <p className="text-xs text-slate-500">An assistant. Not a replacement.</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 rounded-full bg-slate-100 px-4 py-2 text-xs font-medium text-slate-600">
          <span className="h-2 w-2 rounded-full bg-emerald-500" />
          {STORE.name} · {clockLabel}
        </div>
      </div>
    </header>
  );
}
