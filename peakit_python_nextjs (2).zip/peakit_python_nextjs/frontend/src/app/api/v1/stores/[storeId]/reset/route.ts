import { NextRequest, NextResponse } from "next/server";
import { resetStoreState } from "@/lib/domain/storeState";
import { resetToolLog } from "@/lib/domain/tools";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  const state = resetStoreState(storeId);
  resetToolLog(storeId);
  return NextResponse.json({
    storeId: state.storeId,
    storeName: state.storeName,
    simTime: state.simTime.toISOString(),
    weather: state.weather,
    inventory: state.inventory,
  });
}
