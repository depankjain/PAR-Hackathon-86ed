import { NextRequest, NextResponse } from "next/server";
import { resolveState } from "@/lib/domain/requestHelpers";
import { forecastDemand } from "@/lib/domain/tools";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const state = resolveState(body);
  const call = forecastDemand(state, body.itemId, body.windowMinutes);
  return NextResponse.json(call.output);
}
