# PeaKit Backend (Python / FastAPI)

Python port of the PeaKit Spring Boot reference backend, built for **exact
behavioral and API parity** so the shared Next.js frontend can talk to
either backend interchangeably. Same endpoints, same camelCase JSON field
names, same deterministic business-logic formulas, same seed data, same
demo scenario.

Scope, on purpose: **3 capabilities only** — current stock, restock timing,
and demand forecast + runout + footfall. No staffing, no food-safety
features.

## Stack

- Python 3.11+ (developed/tested against 3.10.12 in this sandbox — see
  "What was verified" below)
- FastAPI (sync endpoints — FastAPI runs them in its threadpool)
- SQLAlchemy 2.x, classic sync API, against PostgreSQL
- Pydantic v2 for request/response schemas (camelCase wire names via
  `Field(alias=...)`)
- boto3 for the real AWS Bedrock adapter
- pytest for tests
- uvicorn as the ASGI server
- pydantic-settings for config

## Schema/seed strategy: `create_all()` + idempotent seed function (not raw SQL migrations)

The Java reference backend uses Flyway-style `V1__init.sql` /
`V2__seed_data.sql` files. This Python port deliberately uses
**`SQLAlchemy Base.metadata.create_all()` for schema creation, plus a
hand-written idempotent `seed_demo_data()` function** (`app/seed.py`)
instead of raw SQL migration files.

Rationale: this is a hackathon prototype whose schema will not evolve
independently of the ORM models — there's no multi-environment migration
history to manage, no team of engineers stepping on each other's schema
changes. A migrations runner in that situation is ceremony without payoff.
`create_all()` + "insert if not exists" seeding is the more idiomatic
FastAPI/SQLAlchemy choice for something this size, while still giving the
same guarantee the Java Flyway scripts gave: a fresh database always ends
up in exactly the seeded demo state, and `POST /reset` restores it without
re-running migrations.

## Project layout

```
backend/
  app/
    main.py                       FastAPI app, CORS, router includes, startup seed
    config.py                     pydantic-settings config (DB URL, AI provider, CORS, ...)
    db.py                         SQLAlchemy engine/session (sync)
    models.py                     SQLAlchemy ORM models
    schemas.py                    Pydantic request/response models (camelCase aliases)
    seed.py                       Idempotent demo-store seed + reset
    routers/
      stores.py                  state / advance / reset / audit-log
      tools.py                   forecast / inventory / runout / required-prep / restock-reminder
      agent.py                   /agent/ask
    services/
      demand_forecast.py         the deterministic forecast formula
      tools_service.py           the 5 tool functions + audit logging
      audit_log.py               audit-log persistence helper
      store_state.py             StoreState builder + advance-clock logic
      time_utils.py              naive/aware datetime -> "...Z" wire format helper
      orchestration.py           the /agent/ask dispatcher
      reasoning/
        base.py                  AiReasoningPort seam (Protocol) + intent constants
        local_stub.py            keyword-matching classifier (default provider)
        bedrock_adapter.py       real Bedrock Converse API adapter, falls back to local_stub
  tests/
    conftest.py                  pins DATABASE_URL to a throwaway SQLite file before any import
    test_demand_forecast.py      pure-Python: forecast formula + local intent classifier
    test_api_sqlite_smoke.py     FastAPI TestClient smoke tests against SQLite
  requirements.txt
  Dockerfile
  docker-compose.yml
  .env.example
```

## Running it for real

```bash
cd backend
cp .env.example .env            # edit if needed
docker compose up -d            # starts Postgres on localhost:5433
python -m venv .venv && source .venv/bin/activate   # or your preferred venv tool
pip install -r requirements.txt
uvicorn app.main:app --reload
```

The app creates tables and seeds the demo store (`IN-BLR-0142`) on startup
automatically — nothing else to run. Open `http://localhost:8000/docs` for
interactive Swagger UI, or `http://localhost:8000/openapi.json` for the raw
schema.

Postgres port **5433** (mapped to the container's 5432) was chosen to
mirror the Java reference backend's docker-compose and avoid clashing with
a locally-installed Postgres on the default 5432.

## Design choices / deviations from the spec (and why)

- **`storeId` on tool endpoints (#5-9):** implemented as an optional query
  parameter (`?storeId=...`) defaulting to `IN-BLR-0142`
  (`settings.default_store_id`), rather than adding it to every request
  body. This keeps request bodies identical to the shared
  `ForecastRequest` / `ItemRequest` / `RestockReminderRequest` shapes in the
  OpenAPI contract while still letting inventory lookups and audit-log rows
  know which store they belong to. `POST /reset` similarly always resets
  the one seeded demo store regardless of the `{storeId}` path segment,
  matching the single-store nature of this demo.
- **`minutesToRunout` = "Infinity" sentinel:** JSON has no native Infinity
  literal. When `sellThroughPerMin <= 0`, the field is serialized as the
  **string `"Infinity"`** (not a numeric sentinel, not `null`) — this is
  unambiguous for a frontend to detect (`typeof value === "string"`) without
  colliding with any real numeric value. Documented here and in
  `app/schemas.py` / `app/services/tools_service.py`.
- **Naive vs. aware datetimes:** `app/services/time_utils.py` normalizes any
  naive datetime (which SQLite hands back, but Postgres's `TIMESTAMPTZ`
  never does) to UTC before formatting as `"...Z"`. Likewise
  `demand_forecast.expected_units_in_window` pins a naive `at_utc` to UTC
  before converting to the store's local timezone — `datetime.astimezone()`
  on a naive value silently assumes the *host machine's* local timezone as
  the source, which would have produced silently wrong forecast numbers
  under SQLite. This only matters for the SQLite-based smoke tests; real
  Postgres always returns timezone-aware datetimes.
- **BigInteger primary keys use `.with_variant(Integer, "sqlite")`**
  (`app/models.py`): SQLite's autoincrement-rowid aliasing only activates
  for a bare `INTEGER PRIMARY KEY`, not `BIGINT`. Postgres always sees
  `BigInteger` (functionally equivalent to the reference schema's
  `BIGSERIAL`); this variant only changes behavior under SQLite, again
  purely for the offline smoke tests.
- **Known cosmetic warning:** newer Pydantic (2.13.x) emits an
  `UnsupportedFieldAttributeWarning` on some `Field(alias=...)` declarations
  in `schemas.py` when combined with `from __future__ import annotations`.
  This was investigated: it does **not** affect behavior — every test
  asserts exact camelCase dict equality (e.g.
  `{"itemId": ..., "onHand": ..., "unit": ...}`) and all pass, and manual
  `curl` calls against the running app confirm correct camelCase
  request/response field names throughout. Left as-is rather than
  restructuring the schemas around a cosmetic warning; flagged here for
  visibility.

## What was verified in this sandbox (and what wasn't)

**No real PostgreSQL was available in this sandbox.** Consistent with the
honesty pattern used elsewhere in this project, here's exactly what was and
wasn't checked:

1. **Syntax / imports:** `python -m py_compile` across every `.py` file —
   passed.
2. **Pure-Python unit tests** (`tests/test_demand_forecast.py`, no DB): the
   deterministic forecast formula against a hand-computed expected value
   (chicken_original, Friday 2026-09-18 19:04 IST, 45-minute window →
   `420 * 0.14 * 1.25 * 1.0 = 73.5` units/hour → `73.5 * 45/60 = 55.125` →
   rounds to **55.1**, which the test asserts exactly), the weather
   modifier, the unknown-hour default weight, and the local keyword
   intent classifier on sample queries. **6/6 passed.**
3. **FastAPI TestClient smoke tests against SQLite**
   (`tests/test_api_sqlite_smoke.py`), standing in for Postgres since none
   was available: app boot, OpenAPI schema generation, seed values, the
   `advance` decrement math, `reset` restoring seed state, all 5 tool
   endpoints (including the exact `55.1` forecast value end-to-end through
   the API, the `"Infinity"` sentinel branch, and the audit-log row
   grouping between `forecast_demand` + `required_prep_for_window`), and
   all three `/agent/ask` intents. **14/14 passed** (20/20 across both test
   files).
4. **Live boot smoke test:** ran `uvicorn app.main:app` for real (SQLite
   `DATABASE_URL`, since Postgres isn't available here) and hit it with
   `curl`: `/health`, `/openapi.json`, `GET /stores/IN-BLR-0142/state`, and
   `POST /agent/ask` with a runout-triggering query — all returned correct,
   well-formed camelCase JSON, and the orchestration correctly picked
   `corn_cup` as the "worst" item (29.3 min to runout vs. chicken's 45.2)
   and fired a restock reminder for it.
5. **Bedrock fallback safety, verified for real (not just by inspection):**
   this sandbox's system `boto3`/`urllib3`/`pyOpenSSL` install is broken
   (`AttributeError: module 'lib' has no attribute 'GEN_EMAIL'` on import).
   Calling `BedrockReasoning().classify_intent(...)` against that broken
   environment triggered exactly the intended behavior: the exception was
   caught, a warning was logged, and it fell back to the local stub and
   returned the correct intent. This incidentally exercised the "Bedrock
   outage must never break the endpoint" requirement more thoroughly than
   a clean environment would have.

**NOT verified:** anything requiring a real Postgres connection (actual
`docker-compose up -d` + connecting over `psycopg`, the real
`TIMESTAMPTZ`/`BIGSERIAL`-equivalent column behavior, concurrent-session
behavior) and a real Bedrock `converse()` call with valid AWS credentials
(the request payload shape was written against the documented Converse API
tool-use contract but never round-tripped against the live service).

## AI provider switch

```
PEAKIT_AI_PROVIDER=local     # default — keyword-matching stub, no AWS needed
PEAKIT_AI_PROVIDER=bedrock   # real AWS Bedrock Converse API with forced tool use
PEAKIT_BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0
AWS_REGION=us-east-1
```

Both implementations satisfy the same `AiReasoningPort` protocol
(`app/services/reasoning/base.py`), so `orchestration.py` never knows or
cares which one classified the query. The Bedrock adapter catches *any*
exception — throttling, missing credentials, network error, malformed
response, whatever — logs a warning, and falls back to the local stub. A
Bedrock outage never breaks the endpoint.

## Pairing with the Next.js frontend

Point the frontend at this backend with:

```
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
```

CORS is enabled for `http://localhost:3000` by default
(`CORS_ALLOWED_ORIGINS` in `.env`, comma-separated for multiple origins —
add the deployed frontend's origin there later).
