import { NextRequest, NextResponse } from "next/server";
import { getStoreState } from "@/lib/domain/storeState";

// GET /api/v1/stores/{storeId}/state
// Mock implementation of the contract in api-contract/openapi.yaml.
// The real Python (FastAPI) backend implements this exact shape from
// StoreStateController, reading from PostgreSQL instead of memory.
export async function GET(_req: NextRequest, { params }: { params: Promise<{ storeId: string }> }) {
  const { storeId } = await params;
  const state = getStoreState(storeId);
  return NextResponse.json({
    storeId: state.storeId,
    storeName: state.storeName,
    simTime: state.simTime.toISOString(),
    weather: state.weather,
    inventory: state.inventory,
  });
}
